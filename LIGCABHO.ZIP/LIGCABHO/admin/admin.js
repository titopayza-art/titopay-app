/**
 * Ligcabho admin portal.
 * Hash-routed views over the PHP API in /api. No framework, no build step.
 */
(function () {
  'use strict';

  var API = '../api/';
  var state = { user: null, rows: {}, stats: null };

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function esc(t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function toast(msg, kind) {
    var t = $('#toast');
    t.textContent = msg;
    t.className = 'toast is-on' + (kind ? ' toast--' + kind : '');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.className = 'toast'; }, 3200);
  }

  function api(path, opts) {
    opts = opts || {};
    opts.credentials = 'same-origin';
    if (opts.body && typeof opts.body !== 'string') {
      opts.headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
      opts.body = JSON.stringify(opts.body);
    }
    return fetch(API + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (r.status === 401) { showLogin(); throw new Error(j.error || 'Please sign in again.'); }
        if (!r.ok || j.ok === false) throw new Error(j.error || 'Request failed (' + r.status + ')');
        return j;
      });
    });
  }

  function fmtDate(iso) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' }) +
           ' · ' + d.toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' });
  }

  function badge(v) { return '<span class="badge badge--' + esc(v || 'new') + '">' + esc((v || '—').replace(/_/g, ' ')) + '</span>'; }
  function isOwner() { return state.user && state.user.role === 'owner'; }
  function canDelete() { return state.user && (state.user.role === 'owner' || state.user.role === 'manager'); }

  /* -------------------------------- auth -------------------------------- */
  function showLogin() {
    $('#shell').hidden = true;
    $('#change-pass').hidden = true;
    $('#login').hidden = false;
    state.user = null;
  }

  function showShell() {
    $('#login').hidden = true;
    $('#change-pass').hidden = true;
    $('#shell').hidden = false;
    var name = state.user.name || 'Ligcabho';
    $('#who-name').textContent = name;
    $('#who-role').textContent = state.user.role;
    $('#who-initials').textContent = name.split(/\s+/).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
    $$('[data-owner]').forEach(function (el) { el.hidden = !isOwner(); });
    route();
  }

  function afterAuth(user) {
    state.user = user;
    if (Number(user.must_change_password) === 1) {
      $('#login').hidden = true;
      $('#shell').hidden = true;
      $('#change-pass').hidden = false;
      setTimeout(function () { $('#cp-current').focus(); }, 60);
      return;
    }
    showShell();
  }

  $('#login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var msg = $('#login-msg'), btn = $('#login-btn');
    msg.hidden = true;
    btn.disabled = true; btn.textContent = 'Signing in…';
    api('auth/login', { method: 'POST', body: { email: $('#li-email').value.trim(), password: $('#li-pass').value } })
      .then(function (d) { $('#li-pass').value = ''; afterAuth(d.user); })
      .catch(function (err) { msg.textContent = err.message; msg.hidden = false; })
      .then(function () { btn.disabled = false; btn.textContent = 'Sign in'; });
  });

  $('#cp-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var msg = $('#cp-msg');
    msg.hidden = true;
    if ($('#cp-new').value !== $('#cp-confirm').value) {
      msg.textContent = 'The two new passwords do not match.'; msg.hidden = false; return;
    }
    api('auth/password', { method: 'POST', body: { current_password: $('#cp-current').value, new_password: $('#cp-new').value } })
      .then(function () {
        state.user.must_change_password = 0;
        $('#cp-form').reset();
        toast('Password updated.', 'ok');
        showShell();
      })
      .catch(function (err) { msg.textContent = err.message; msg.hidden = false; });
  });

  $('#sign-out').addEventListener('click', function () {
    api('auth/logout', { method: 'POST' }).then(showLogin).catch(showLogin);
  });

  $('#side-toggle').addEventListener('click', function () { $('.side').classList.toggle('is-open'); });
  $('#detail-close').addEventListener('click', function () { $('#detail').hidden = true; });

  /* ------------------------------- views -------------------------------- */
  var VIEWS = {
    applications: {
      title: 'Applications', endpoint: 'applications',
      statuses: ['new', 'reviewing', 'accepted', 'waitlist', 'placed', 'rejected'],
      columns: [
        ['reference', 'Reference'],
        ['name', 'Applicant', function (r) { return esc((r.first_name || '') + ' ' + (r.last_name || '')); }],
        ['institution', 'Institution'],
        ['residence', 'Residence', function (r) { return esc(r.residence || 'No preference'); }],
        ['funder', 'Funder'],
        ['status', 'Status', function (r) { return badge(r.status); }],
        ['created_at', 'Received', function (r) { return '<span class="nowrap">' + esc(fmtDate(r.created_at)) + '</span>'; }]
      ],
      detail: [
        ['reference', 'Reference'], ['first_name', 'First name'], ['last_name', 'Last name'],
        ['id_number', 'ID number'], ['student_number', 'Student number'], ['gender', 'Gender'],
        ['phone', 'Phone'], ['email', 'Email'], ['level', 'Level of study'], ['institution', 'Institution'],
        ['funder', 'Funder'], ['year', 'Year'], ['residence', 'Preferred residence'],
        ['room_type', 'Room type'], ['notes', 'Applicant notes'], ['created_at', 'Received', fmtDate]
      ]
    },
    enquiries: {
      title: 'Enquiries', endpoint: 'enquiries',
      statuses: ['new', 'in_progress', 'answered', 'closed'],
      columns: [
        ['name', 'From'], ['email', 'Email'], ['phone', 'Phone'],
        ['residence', 'About', function (r) { return esc(r.residence || r.topic || 'General'); }],
        ['status', 'Status', function (r) { return badge(r.status); }],
        ['created_at', 'Received', function (r) { return '<span class="nowrap">' + esc(fmtDate(r.created_at)) + '</span>'; }]
      ],
      detail: [['name', 'Name'], ['email', 'Email'], ['phone', 'Phone'], ['topic', 'Topic'],
               ['residence', 'Residence'], ['message', 'Message'], ['created_at', 'Received', fmtDate]]
    },
    orders: {
      title: 'LVL UP orders', endpoint: 'orders',
      statuses: ['new', 'paid', 'ready', 'collected', 'cancelled'],
      columns: [
        ['reference', 'Reference'], ['pack', 'Pack'], ['name', 'Student'], ['phone', 'Phone'],
        ['status', 'Status', function (r) { return badge(r.status); }],
        ['created_at', 'Ordered', function (r) { return '<span class="nowrap">' + esc(fmtDate(r.created_at)) + '</span>'; }]
      ],
      detail: [['reference', 'Reference'], ['pack', 'Pack'], ['name', 'Name'], ['email', 'Email'],
               ['phone', 'Phone'], ['created_at', 'Ordered', fmtDate]]
    },
    careers: {
      title: 'Job applications', endpoint: 'job-applications',
      statuses: ['new', 'reviewing', 'shortlisted', 'appointed', 'declined'],
      columns: [
        ['name', 'Candidate'], ['role', 'Position'], ['email', 'Email'], ['phone', 'Phone'],
        ['status', 'Status', function (r) { return badge(r.status); }],
        ['created_at', 'Received', function (r) { return '<span class="nowrap">' + esc(fmtDate(r.created_at)) + '</span>'; }]
      ],
      detail: [['name', 'Name'], ['email', 'Email'], ['phone', 'Phone'], ['role', 'Position'],
               ['message', 'Motivation'], ['created_at', 'Received', fmtDate]]
    },
    subscribers: {
      title: 'Newsletter', endpoint: 'subscribers', statuses: [],
      columns: [['name', 'Name'], ['email', 'Email'],
                ['created_at', 'Subscribed', function (r) { return esc(fmtDate(r.created_at)); }]],
      detail: [['name', 'Name'], ['email', 'Email'], ['created_at', 'Subscribed', fmtDate]]
    }
  };

  function renderList(key) {
    var cfg = VIEWS[key];
    $('#view-title').textContent = cfg.title;

    var statusOpts = cfg.statuses.map(function (s) {
      return '<option value="' + s + '">' + esc(s.replace(/_/g, ' ')) + '</option>';
    }).join('');

    $('#view').innerHTML =
      '<div class="toolbar">' +
        '<input id="q" type="search" placeholder="Search…">' +
        (cfg.statuses.length ? '<select id="status"><option value="">All statuses</option>' + statusOpts + '</select>' : '') +
        '<span class="spacer"></span>' +
        '<a class="btn btn--ghost btn--sm" href="' + API + cfg.endpoint + '/export">Export CSV</a>' +
      '</div><div class="tablewrap" id="table"></div>';

    var load = function () {
      var q = ($('#q') && $('#q').value.trim()) || '';
      var st = ($('#status') && $('#status').value) || '';
      var qs = [];
      if (q) qs.push('q=' + encodeURIComponent(q));
      if (st) qs.push('status=' + encodeURIComponent(st));
      $('#table').innerHTML = '<p class="empty">Loading…</p>';
      api(cfg.endpoint + (qs.length ? '?' + qs.join('&') : ''))
        .then(function (d) { state.rows[key] = d.rows; paint(d.rows); })
        .catch(function (e) { $('#table').innerHTML = '<p class="empty">' + esc(e.message) + '</p>'; });
    };

    var paint = function (rows) {
      if (!rows.length) { $('#table').innerHTML = '<p class="empty">Nothing here yet.</p>'; return; }
      var head = cfg.columns.map(function (c) { return '<th>' + esc(c[1]) + '</th>'; }).join('');
      var body = rows.map(function (r, i) {
        var tds = cfg.columns.map(function (c) {
          return '<td>' + (c[2] ? c[2](r) : esc(r[c[0]] || '—')) + '</td>';
        }).join('');
        return '<tr data-i="' + i + '">' + tds + '</tr>';
      }).join('');
      $('#table').innerHTML = '<table class="data"><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table>';
      $$('#table tbody tr').forEach(function (tr) {
        tr.addEventListener('click', function () { openDetail(key, rows[Number(tr.dataset.i)]); });
      });
    };

    if ($('#q')) {
      var t;
      $('#q').addEventListener('input', function () { clearTimeout(t); t = setTimeout(load, 250); });
    }
    if ($('#status')) $('#status').addEventListener('change', load);
    load();
  }

  function openDetail(key, row) {
    var cfg = VIEWS[key];
    $('#detail-title').textContent = cfg.title.replace(/s$/, '') + ' detail';

    var dl = cfg.detail.map(function (f) {
      var v = f[2] ? f[2](row[f[0]]) : row[f[0]];
      return '<dt>' + esc(f[1]) + '</dt><dd>' + esc(v || '—') + '</dd>';
    }).join('');

    var doc = row.document
      ? '<p><a class="btn btn--ghost btn--sm" href="' + API + 'files/' + encodeURIComponent(row.document) +
        '" target="_blank" rel="noopener">Open attached document</a></p>' : '';

    var statusSel = cfg.statuses.length
      ? '<div class="field"><label for="d-status">Status</label><select id="d-status">' +
        cfg.statuses.map(function (s) {
          return '<option value="' + s + '"' + (row.status === s ? ' selected' : '') + '>' + esc(s.replace(/_/g, ' ')) + '</option>';
        }).join('') + '</select></div>' : '';

    var notes = cfg.statuses.length
      ? '<div class="field"><label for="d-notes">Internal notes</label><textarea id="d-notes">' +
        esc(row.staff_notes || '') + '</textarea></div>' : '';

    $('#detail-body').innerHTML =
      '<dl>' + dl + '</dl>' + doc + statusSel + notes +
      '<div class="actions">' +
        (cfg.statuses.length ? '<button class="btn btn--primary btn--sm" id="d-save" type="button">Save changes</button>' : '') +
        (row.email ? '<a class="btn btn--ghost btn--sm" href="mailto:' + esc(row.email) + '">Email</a>' : '') +
        (row.phone ? '<a class="btn btn--ghost btn--sm" href="https://wa.me/27' + esc(String(row.phone).replace(/\D/g, '').replace(/^27/, '').replace(/^0/, '')) + '">WhatsApp</a>' : '') +
        (canDelete() ? '<button class="btn btn--danger btn--sm" id="d-del" type="button">Delete</button>' : '') +
      '</div>';

    $('#detail').hidden = false;

    if ($('#d-save')) {
      $('#d-save').addEventListener('click', function () {
        api(cfg.endpoint + '/' + row.id, {
          method: 'PATCH',
          body: { status: $('#d-status').value, staff_notes: $('#d-notes').value }
        }).then(function () {
          toast('Saved.', 'ok');
          $('#detail').hidden = true;
          renderList(key);
          refreshCounts();
        }).catch(function (e) { toast(e.message, 'err'); });
      });
    }
    if ($('#d-del')) {
      $('#d-del').addEventListener('click', function () {
        if (!window.confirm('Delete this record permanently? This cannot be undone.')) return;
        api(cfg.endpoint + '/' + row.id, { method: 'DELETE' }).then(function () {
          toast('Deleted.', 'ok');
          $('#detail').hidden = true;
          renderList(key);
          refreshCounts();
        }).catch(function (e) { toast(e.message, 'err'); });
      });
    }
  }

  /* ------------------------------ dashboard ------------------------------ */
  function renderDashboard() {
    $('#view-title').textContent = 'Dashboard';
    $('#view').innerHTML = '<p class="empty">Loading…</p>';

    api('stats').then(function (d) {
      var s = d.stats;
      state.stats = s;
      var max = Math.max.apply(null, [1].concat(s.by_residence.map(function (r) { return Number(r.n); })));

      var bars = s.by_residence.map(function (r) {
        return '<div class="bar"><span>' + esc(r.residence) + '</span><strong>' + esc(r.n) + '</strong>' +
          '<span class="bar__track"><span class="bar__fill" style="width:' +
          Math.round((Number(r.n) / max) * 100) + '%"></span></span></div>';
      }).join('') || '<p class="empty">No applications yet.</p>';

      var recent = s.recent.length ? s.recent.map(function (r) {
        return '<tr><td>' + esc(r.reference) + '</td><td>' + esc((r.first_name || '') + ' ' + (r.last_name || '')) +
          '</td><td>' + esc(r.residence || 'No preference') + '</td><td>' + badge(r.status) +
          '</td><td class="nowrap">' + esc(fmtDate(r.created_at)) + '</td></tr>';
      }).join('') : '<tr><td colspan="5" class="empty">No applications yet.</td></tr>';

      $('#view').innerHTML =
        '<div class="stats">' +
          stat(s.applications, 'Applications, all time') +
          stat(s.applications_new, 'Applications awaiting review') +
          stat(s.applications_week, 'Received in the last 7 days') +
          stat(s.enquiries_open, 'Open enquiries') +
          stat(s.orders, 'LVL UP orders') +
          stat(s.subscribers, 'Newsletter subscribers') +
        '</div>' +
        '<div class="grid2">' +
          '<div class="panel"><h2>Applications by residence</h2><div class="bars">' + bars + '</div></div>' +
          '<div class="panel"><h2>Where applications stand</h2><div class="bars">' +
            ['new', 'reviewing', 'accepted', 'waitlist', 'placed', 'rejected'].map(function (k) {
              var n = s.by_status[k] || 0;
              var tot = Math.max(1, s.applications);
              return '<div class="bar"><span>' + badge(k) + '</span><strong>' + n + '</strong>' +
                '<span class="bar__track"><span class="bar__fill" style="width:' + Math.round((n / tot) * 100) + '%"></span></span></div>';
            }).join('') +
          '</div></div>' +
        '</div>' +
        '<div class="panel"><h2>Latest applications</h2><div class="tablewrap"><table class="data"><thead><tr>' +
        '<th>Reference</th><th>Applicant</th><th>Residence</th><th>Status</th><th>Received</th></tr></thead><tbody>' +
        recent + '</tbody></table></div></div>';
    }).catch(function (e) { $('#view').innerHTML = '<p class="empty">' + esc(e.message) + '</p>'; });
  }

  function stat(n, label) {
    return '<div class="stat"><strong>' + esc(n) + '</strong><span>' + esc(label) + '</span></div>';
  }

  /* -------------------------------- users -------------------------------- */
  function renderUsers() {
    $('#view-title').textContent = 'Staff accounts';
    $('#view').innerHTML =
      '<div class="panel"><h2>Add a staff account</h2>' +
        '<form id="u-form" class="grid2">' +
          '<div class="field"><label for="u-name">Full name</label><input id="u-name" required></div>' +
          '<div class="field"><label for="u-email">Email address</label><input id="u-email" type="email" required></div>' +
          '<div class="field"><label for="u-role">Role</label><select id="u-role">' +
            '<option value="staff">Staff — read and update records</option>' +
            '<option value="manager">Manager — also delete records</option>' +
            '<option value="owner">Owner — full access, manages accounts</option>' +
          '</select></div>' +
          '<div class="field"><label>&nbsp;</label><button class="btn btn--primary" type="submit">Add account</button></div>' +
        '</form>' +
        '<p class="hint">New accounts start on the shared temporary password and must change it at first sign-in.</p>' +
      '</div><div class="tablewrap" id="u-table"></div>';

    var load = function () {
      api('users').then(function (d) {
        $('#u-table').innerHTML =
          '<table class="data"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th>' +
          '<th>Last sign-in</th><th>Actions</th></tr></thead><tbody>' +
          d.rows.map(function (u) {
            var self = state.user && Number(state.user.id) === Number(u.id);
            return '<tr><td>' + esc(u.name) + (self ? ' <span class="badge">you</span>' : '') + '</td><td>' + esc(u.email) + '</td>' +
              '<td>' + (self ? esc(u.role) : '<select data-role="' + u.id + '">' +
                ['owner', 'manager', 'staff'].map(function (r) {
                  return '<option value="' + r + '"' + (u.role === r ? ' selected' : '') + '>' + r + '</option>';
                }).join('') + '</select>') + '</td>' +
              '<td>' + (Number(u.active) ? badge('placed') : badge('rejected')) +
                (Number(u.must_change_password) ? ' <span class="badge badge--new">temp password</span>' : '') + '</td>' +
              '<td class="nowrap">' + esc(u.last_login_at ? fmtDate(u.last_login_at) : 'Never') + '</td>' +
              '<td class="nowrap">' +
                '<button class="btn btn--ghost btn--sm" data-reset="' + u.id + '">Reset password</button> ' +
                (self ? '' : '<button class="btn btn--ghost btn--sm" data-active="' + u.id + '" data-to="' +
                  (Number(u.active) ? 0 : 1) + '">' + (Number(u.active) ? 'Deactivate' : 'Activate') + '</button>') +
              '</td></tr>';
          }).join('') + '</tbody></table>';

        $$('#u-table [data-role]').forEach(function (sel) {
          sel.addEventListener('change', function () {
            api('users/' + sel.dataset.role, { method: 'PATCH', body: { role: sel.value } })
              .then(function () { toast('Role updated.', 'ok'); })
              .catch(function (e) { toast(e.message, 'err'); load(); });
          });
        });
        $$('#u-table [data-reset]').forEach(function (b) {
          b.addEventListener('click', function () {
            if (!window.confirm('Reset this account to the shared temporary password?')) return;
            api('users/' + b.dataset.reset + '/reset', { method: 'POST' })
              .then(function () { toast('Password reset.', 'ok'); load(); })
              .catch(function (e) { toast(e.message, 'err'); });
          });
        });
        $$('#u-table [data-active]').forEach(function (b) {
          b.addEventListener('click', function () {
            api('users/' + b.dataset.active, { method: 'PATCH', body: { active: Number(b.dataset.to) } })
              .then(function () { toast('Saved.', 'ok'); load(); })
              .catch(function (e) { toast(e.message, 'err'); });
          });
        });
      }).catch(function (e) { $('#u-table').innerHTML = '<p class="empty">' + esc(e.message) + '</p>'; });
    };

    $('#u-form').addEventListener('submit', function (e) {
      e.preventDefault();
      api('users', { method: 'POST', body: { name: $('#u-name').value.trim(), email: $('#u-email').value.trim(), role: $('#u-role').value } })
        .then(function (d) { toast(d.message, 'ok'); $('#u-form').reset(); load(); })
        .catch(function (err) { toast(err.message, 'err'); });
    });
    load();
  }

  function renderActivity() {
    $('#view-title').textContent = 'Activity log';
    $('#view').innerHTML = '<p class="empty">Loading…</p>';
    api('audit').then(function (d) {
      $('#view').innerHTML = '<div class="tablewrap"><table class="data"><thead><tr><th>When</th><th>Who</th>' +
        '<th>Action</th><th>Detail</th></tr></thead><tbody>' +
        (d.rows.map(function (r) {
          return '<tr><td class="nowrap">' + esc(fmtDate(r.at)) + '</td><td>' + esc(r.user_email) +
            '</td><td>' + esc(r.action) + '</td><td>' + esc(r.detail) + '</td></tr>';
        }).join('') || '<tr><td colspan="4" class="empty">Nothing logged yet.</td></tr>') +
        '</tbody></table></div>';
    }).catch(function (e) { $('#view').innerHTML = '<p class="empty">' + esc(e.message) + '</p>'; });
  }

  /* -------------------------------- routing ------------------------------ */
  function refreshCounts() {
    api('stats').then(function (d) {
      $('#pill-apps').textContent = d.stats.applications_new;
      $('#pill-enq').textContent = d.stats.enquiries_open;
    }).catch(function () {});
  }

  function route() {
    if (!state.user) return;
    var key = (location.hash || '#/dashboard').replace('#/', '');
    $$('[data-nav]').forEach(function (a) { a.classList.toggle('is-on', a.dataset.nav === key); });
    $('#detail').hidden = true;
    $('.side').classList.remove('is-open');

    if (VIEWS[key]) renderList(key);
    else if (key === 'users' && isOwner()) renderUsers();
    else if (key === 'activity' && isOwner()) renderActivity();
    else renderDashboard();

    refreshCounts();
  }

  window.addEventListener('hashchange', route);

  /* -------------------------------- start -------------------------------- */
  api('auth/me')
    .then(function (d) { afterAuth(d.user); })
    .catch(function () { showLogin(); });
})();
