# Ligcabho Le'Africa Residences — website and admin portal

A complete rebuild of ligcabhoresidences.co.za: 32 static pages, a JSON API and a staff admin
portal. No build step and no framework — upload the folder and it runs.

---

## 1. What is in the box

```
/                       15 site pages + 17 residence pages
  index.html            home
  residences.html       all residences, filterable by institution, area and room type
  residence-*.html      one page per residence, with photo gallery and enquiry form
  apply.html            online application (with document upload)
  student-zone.html     lease, house rules, emergency list, maintenance, packs
  lvl-up.html           LVL UP kitchen (R700) and bedding (R600) packs + order forms
  student-safety.html   safety features and emergency procedure
  emergency.html        emergency contact list
  about-us.html         who we are, vision, how the residence is run
  accreditations.html   UMP, TUT, NSFAS, bursary, cash
  urban-regeneration.html
  careers.html          job search + application form with CV upload
  faqs.html             the full FAQ, marked up as schema.org FAQPage
  house-rules.html      the eleven house rule policies
  get-in-touch.html     contact details, banking details, contact form
  404.html
  sitemap.xml, robots.txt, .htaccess

/assets
  css/styles.css        the design system
  js/main.js            nav, filters, lightbox, form submission
  img/brand             logo, light logo, favicons
  img/residences        photographs, one set per residence
  img/institutions      institution logos
  docs                  lease agreement, house rules and emergency numbers (PDF)

/api
  index.php             the whole API: auth, form intake, staff CRUD, CSV export
  .htaccess             routes /api/... to index.php
  data/                 created on first run — SQLite database + uploads (never served)

/admin
  index.html, admin.css, admin.js
```

## 2. Deploying (Afrihost, cPanel or any PHP host)

1. Upload the **contents** of this folder to `public_html/` (so `index.html` sits at the web root).
2. Make sure PHP 7.4 or later is selected for the domain, with PDO SQLite enabled (it is on by default).
3. Give the web server write access to `api/data` (755 on the folder is usually enough; 775 if not).
4. Visit `https://ligcabhoresidences.co.za/` to check the site, then `/admin/` to sign in.

The database, the tables and the five staff accounts are all created automatically the first time
any API request runs. There is nothing to import.

## 3. Admin portal

Open `https://ligcabhoresidences.co.za/admin/`.

| Email                              | Role    | Can do                                      |
|------------------------------------|---------|---------------------------------------------|
| admin@ligcabhoresidences.co.za     | Owner   | Everything, including staff accounts        |
| ceo@ligcabhoresidences.co.za       | Owner   | Everything, including staff accounts        |
| e.director@ligcabhoresidences.co.za| Owner   | Everything, including staff accounts        |
| manager@ligcabhoresidences.co.za   | Manager | All records, including deleting them        |
| support@ligcabhoresidences.co.za   | Staff   | Read records, change status, add notes      |

**Temporary password for all five accounts: `#47LigcabhoRes`**

Every account is forced to choose a new password (10 characters or more, and not the temporary
one) the first time it signs in. Owners can add more accounts, change roles, deactivate an account
and reset a password back to the temporary one from **Staff accounts**.

What the portal shows:

- **Dashboard** — applications all-time, awaiting review and in the last 7 days, open enquiries,
  pack orders, subscribers, applications by residence and by status, and the latest applications.
- **Applications** — search, filter by status, open a record for the full detail, view the uploaded
  proof of payment, set the status (new → reviewing → accepted / waitlist / placed / rejected),
  keep internal notes, email or WhatsApp the applicant, export to CSV.
- **Enquiries**, **LVL UP orders**, **Job applications**, **Newsletter** — the same pattern.
- **Staff accounts** and **Activity log** — owners only. Every sign-in, failed sign-in, record
  change and account change is logged.

## 4. Security notes

- Passwords are stored with PHP `password_hash()` (bcrypt); the temporary password is never stored
  in plain text and cannot be reused as a new password.
- Sign-in is rate limited to 8 attempts per email and IP address per 15 minutes.
- Sessions are HTTP-only, SameSite=Lax, and marked Secure over HTTPS.
- Uploaded documents live in `api/data/uploads`, are never served by Apache directly, and can only
  be fetched through `/api/files/<name>` by a signed-in staff member.
- `api/data` carries its own deny-all `.htaccess`, and the SQLite files are blocked by extension.
- Applicant records contain ID numbers: treat the portal as POPIA-sensitive and do not share logins.

## 5. Changing content

The residence data, FAQs, house rules and contact details are written into the HTML pages, so any
edit is a normal HTML edit. Photographs live in `assets/img/residences/` and are named after their
residence, so adding a photo is a copy and one `<button>` in that residence's gallery.

To change the announcement in the top bar ("Applications for 2027 now open"), search for that text
in the HTML files and replace it.

## 6. Local preview

```
php -S localhost:8000        # from the site root — serves the pages and the API
```

Then open http://localhost:8000/ and http://localhost:8000/admin/.
