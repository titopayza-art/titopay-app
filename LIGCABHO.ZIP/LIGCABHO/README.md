# Ligcabho Le'Africa Residences — website, digital leases and admin portal

A complete rebuild of ligcabhoresidences.co.za: 34 static pages, an application assistant, a
digital lease agreement, a JSON API and a staff admin portal. No build step and no framework —
upload the folder and it runs on ordinary PHP hosting.

---

## 1. What is in the box

```
/                         17 content pages + 17 residence pages
  index.html              home
  residences.html         all residences, filterable by institution, area and room type
  residence-*.html        one page per residence, with photo gallery and enquiry form
  apply.html              online application (document upload, or apply by chat)
  student-zone.html       lease, house rules, emergency list, and the maintenance request form
  reviews.html            published student reviews + leave a review
  notice-to-vacate.html   give notice / cancel a lease
  lvl-up.html             LVL UP kitchen (R700) and bedding (R600) packs + order forms
  student-safety.html     safety features and emergency procedure
  emergency.html          emergency contact list
  about-us.html           who we are, vision, how the residence is run
  accreditations.html     UMP, TUT, NSFAS, bursary, cash
  urban-regeneration.html
  careers.html            job search + application form with CV upload
  faqs.html               the full FAQ, marked up as schema.org FAQPage
  house-rules.html        the eleven house rule policies
  get-in-touch.html       contact details, banking details, contact form
  lease.html              the digital lease a tenant opens, reads and signs
  404.html, sitemap.xml, robots.txt, .htaccess

/assets
  css/styles.css          the design system
  css/chat.css            the application assistant
  css/lease.css           the lease agreement (screen and print)
  js/main.js              nav, filters, lightbox, forms, published reviews
  js/chat.js              the application assistant
  js/lease.js             lease rendering and signature capture
  js/residences.js        residence list, generated at build time
  img/…                   brand marks, residence photographs, institution logos
  docs/…                  lease agreement, house rules, emergency numbers (PDF)

/api
  config.php              everything an installation changes lives here
  bootstrap.php           database, schema, sessions, mail, uploads, helpers
  index.php               the API routes
  .htaccess               routes /api/... to index.php

/data                     created on first run, never served
  ligcabho.sqlite         the database
  uploads/                proofs of payment, funding letters, CVs

/admin
  index.html, admin.css, admin.js
  vendor/                 XLSX and jsPDF, for Excel and PDF exports
```

## 2. Deploying (Afrihost, cPanel or any PHP host)

1. Upload the **contents** of this folder to `public_html/` (so `index.html` sits at the web root).
2. Select PHP 7.4 or later for the domain. PDO SQLite is on by default; nothing else is needed.
3. Make `data/` writable by the web server (755 is usually enough, 775 if not).
4. Open `https://ligcabhoresidences.co.za/` to check the site, then `/admin/` to sign in.

The database, the tables, the five staff accounts, the seventeen residences and the current
vacancy are all created automatically on the first request. There is nothing to import.

**Prefer MySQL?** Create the database in cPanel, then set `driver => 'mysql'` and the credentials
in `api/config.php`. The schema is created on the next request.

## 3. Admin portal

`https://ligcabhoresidences.co.za/admin/`

| Email                               | Role    | Can do                                                  |
|-------------------------------------|---------|---------------------------------------------------------|
| admin@ligcabhoresidences.co.za      | Owner   | Everything, including staff accounts and the activity log |
| ceo@ligcabhoresidences.co.za        | Owner   | Everything, including staff accounts                     |
| e.director@ligcabhoresidences.co.za | Owner   | Everything, including staff accounts                     |
| manager@ligcabhoresidences.co.za    | Manager | All records, leases, vacancies, rates, deletions          |
| support@ligcabhoresidences.co.za    | Staff   | Read records, change status, add notes                    |

**Temporary password for all five: `#47LigcabhoRes`** — every account must set its own password
(10 characters or more, and not the temporary one) at first sign-in.

### Today
One inbox of everything waiting on the office: new applications, enquiries, maintenance tickets,
notices to vacate, reviews to publish, leases to counter-sign, job applications and pack orders.
Each row opens the record itself. Four tiles underneath show what is outstanding.

### The views

- **Applications** — search, filter by status, open the full record, view the uploaded proof of
  payment, move the status along (new → reviewing → accepted / waitlist / placed / rejected),
  keep internal notes, email or WhatsApp the applicant, and **create their lease in one click**.
- **Leases** — create a lease (it fills itself in from the rate card), send it to the tenant by
  email, watch it come back signed, counter-sign it, or cancel it. Every lease has its own
  unguessable link.
- **Enquiries**, **Maintenance**, **Cancellations**, **Reviews**, **LVL UP orders**, **Careers**,
  **Newsletter** — the same pattern: search, filter, open, set status, note, export.
- **Reviews** — publish, reply publicly, or hide. Published reviews appear on `reviews.html`
  straight away, with the office reply underneath.
- **Residences & rates** — capacity, how many beds are placed, how many are free, and the **rate
  card**: single rate, sharing rate, deposit and administration fee per residence. New leases read
  their money fields from here, and can still be overridden per lease.
- **Chat transcripts** — every conversation the application assistant had, and how it ended.
- **Dashboard** — occupancy per residence, who is funding students, where applications stand.
- **Staff accounts** and **Activity log** — owners only.

Exports: Excel, PDF and CSV from every record view.

## 4. What students can do on the site

- Apply online with documents, **or apply by chat** — the assistant asks the same questions and
  creates the same application (it never pretends to be a person).
- Log a maintenance request and get a ticket number (MNT…) that the house warden works from.
- Give notice to vacate and get a reference (CXL…), with the notice period and inspection
  explained up front.
- Leave a review of their residence, which the office publishes or answers.
- Order LVL UP packs, subscribe to the newsletter, apply for a job, enquire about any residence.

Everything above lands in the portal the moment it is submitted, and is emailed to the office.

## 5. Security notes

- Passwords are hashed with `password_hash()` (bcrypt). The temporary password cannot be reused
  as a new password.
- Sign-in is rate limited to 8 attempts per IP per 15 minutes.
- Sessions are HTTP-only, SameSite=Lax and Secure over HTTPS, and expire after 8 hours.
- ID numbers are validated (13 digits with the Luhn check digit) in the browser and again on the
  server.
- Uploads live in `data/uploads`, are never served by Apache, and are only readable through
  `/api/files/<name>` by a signed-in staff member.
- Lease links use a 32-character random token; a lease cannot be opened before it is sent, cannot
  be signed twice, and only accepts a signature when the typed name matches the lease exactly.
- Every sign-in, failed sign-in, record change, lease action and account change is written to the
  activity log.
- Applicant records contain ID numbers: treat the portal as POPIA-sensitive and do not share
  logins.

## 6. Changing things

- **Rates** — Residences & rates in the portal. Nothing to edit in code.
- **Email recipients, bank details, landlord details, session length** — `api/config.php`.
- **The announcement** ("Applications for 2027 now open") — search the HTML files for that text.
- **Photographs** — `assets/img/residences/`, named after their residence.
- **Lease clauses** — `assets/js/lease.js`, in one readable list near the top.

## 7. Local preview

```
php -S localhost:8000        # from the site root — serves the pages and the API
```

Then open http://localhost:8000/ and http://localhost:8000/admin/.
