<?php
/**
 * Ligcabho Le'Africa Residences — JSON API.
 *
 * One file, PDO + SQLite, no dependencies. Works on any PHP 7.4+ shared host.
 * Public endpoints accept the website forms; everything else needs a session.
 *
 * Routing: /api/<resource>[/<id>[/<action>]]
 */

declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);
date_default_timezone_set('Africa/Johannesburg');

const DATA_DIR    = __DIR__ . '/data';
const DB_FILE     = DATA_DIR . '/ligcabho.sqlite';
const UPLOAD_DIR  = DATA_DIR . '/uploads';
const TEMP_PASS   = '#47LigcabhoRes';
const MAX_UPLOAD  = 8388608; // 8 MB
const LOGIN_LIMIT = 8;       // attempts per 15 minutes per email+IP

/* ---------------------------------------------------------------- bootstrap */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store');

if (!is_dir(DATA_DIR))   @mkdir(DATA_DIR, 0775, true);
if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0775, true);
@file_put_contents(DATA_DIR . '/.htaccess', "Require all denied\nDeny from all\n");

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'httponly' => true,
    'samesite' => 'Lax',
    'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
]);
session_name('LIGCABHOSESS');
session_start();

/* ------------------------------------------------------------------ helpers */

function fail(string $message, int $code = 400): void
{
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $message]);
    exit;
}

function ok(array $payload = []): void
{
    echo json_encode(array_merge(['ok' => true], $payload));
    exit;
}

function body(): array
{
    if (!empty($_POST) || !empty($_FILES)) return $_POST;
    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function field(array $src, string $key, bool $required = false, int $max = 2000): string
{
    $v = isset($src[$key]) ? trim((string) $src[$key]) : '';
    $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $v) ?? '';
    if ($required && $v === '') fail('Please complete the "' . str_replace('_', ' ', $key) . '" field.');
    if (mb_strlen($v) > $max) $v = mb_substr($v, 0, $max);
    return $v;
}

function email_field(array $src, string $key, bool $required = true): string
{
    $v = field($src, $key, $required, 190);
    if ($v !== '' && !filter_var($v, FILTER_VALIDATE_EMAIL)) fail('That email address does not look right.');
    return strtolower($v);
}

function client_ip(): string
{
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function reference(string $prefix): string
{
    return $prefix . date('y') . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
}

/* ----------------------------------------------------------------- database */

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    try {
        $pdo = new PDO('sqlite:' . DB_FILE, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (Throwable $e) {
        fail('The database is unavailable. Please try again shortly.', 500);
    }

    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA foreign_keys = ON');

    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'staff',
        password_hash TEXT NOT NULL,
        must_change_password INTEGER NOT NULL DEFAULT 1,
        active INTEGER NOT NULL DEFAULT 1,
        last_login_at TEXT,
        created_at TEXT NOT NULL
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reference TEXT UNIQUE NOT NULL,
        first_name TEXT, last_name TEXT, id_number TEXT, student_number TEXT,
        phone TEXT, email TEXT, gender TEXT, level TEXT, institution TEXT,
        funder TEXT, year TEXT, residence TEXT, room_type TEXT, notes TEXT,
        document TEXT, status TEXT NOT NULL DEFAULT 'new',
        staff_notes TEXT, ip TEXT, created_at TEXT NOT NULL, updated_at TEXT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS enquiries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT, email TEXT, phone TEXT, topic TEXT, residence TEXT,
        message TEXT, status TEXT NOT NULL DEFAULT 'new',
        staff_notes TEXT, ip TEXT, created_at TEXT NOT NULL, updated_at TEXT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reference TEXT UNIQUE NOT NULL,
        pack TEXT, name TEXT, email TEXT, phone TEXT,
        status TEXT NOT NULL DEFAULT 'new',
        staff_notes TEXT, created_at TEXT NOT NULL, updated_at TEXT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS job_applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT, email TEXT, phone TEXT, role TEXT, message TEXT,
        document TEXT, status TEXT NOT NULL DEFAULT 'new',
        staff_notes TEXT, created_at TEXT NOT NULL, updated_at TEXT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS subscribers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT, email TEXT UNIQUE NOT NULL,
        created_at TEXT NOT NULL
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT NOT NULL, at TEXT NOT NULL
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT, action TEXT, detail TEXT, at TEXT NOT NULL
    )");

    seed_users($pdo);
    return $pdo;
}

function seed_users(PDO $pdo): void
{
    $seed = [
        ['admin@ligcabhoresidences.co.za',      'Administrator',      'owner'],
        ['ceo@ligcabhoresidences.co.za',        'Chief Executive',    'owner'],
        ['e.director@ligcabhoresidences.co.za', 'Executive Director', 'owner'],
        ['manager@ligcabhoresidences.co.za',    'Residence Manager',  'manager'],
        ['support@ligcabhoresidences.co.za',    'Student Support',    'staff'],
    ];
    $find = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $add  = $pdo->prepare('INSERT INTO users (email, name, role, password_hash, must_change_password, active, created_at)
                           VALUES (?, ?, ?, ?, 1, 1, ?)');
    foreach ($seed as [$email, $name, $role]) {
        $find->execute([$email]);
        if (!$find->fetch()) {
            $add->execute([$email, $name, $role, password_hash(TEMP_PASS, PASSWORD_DEFAULT), date('c')]);
        }
    }
}

function audit(string $action, string $detail = ''): void
{
    $email = $_SESSION['user']['email'] ?? 'public';
    $st = db()->prepare('INSERT INTO audit_log (user_email, action, detail, at) VALUES (?, ?, ?, ?)');
    $st->execute([$email, $action, $detail, date('c')]);
}

/* --------------------------------------------------------------------- auth */

function current_user(): ?array
{
    if (empty($_SESSION['user']['id'])) return null;
    $st = db()->prepare('SELECT id, email, name, role, must_change_password, active FROM users WHERE id = ?');
    $st->execute([$_SESSION['user']['id']]);
    $u = $st->fetch();
    if (!$u || (int) $u['active'] !== 1) return null;
    return $u;
}

function require_user(): array
{
    $u = current_user();
    if (!$u) fail('Please sign in again.', 401);
    if ((int) $u['must_change_password'] === 1) fail('Set a new password before continuing.', 403);
    return $u;
}

function require_role(array $roles): array
{
    $u = require_user();
    if (!in_array($u['role'], $roles, true)) fail('Your role does not allow that action.', 403);
    return $u;
}

function throttled(string $key): bool
{
    $pdo = db();
    $pdo->prepare("DELETE FROM login_attempts WHERE at < ?")->execute([date('c', time() - 900)]);
    $st = $pdo->prepare('SELECT COUNT(*) AS n FROM login_attempts WHERE key = ?');
    $st->execute([$key]);
    return ((int) $st->fetch()['n']) >= LOGIN_LIMIT;
}

function note_attempt(string $key): void
{
    db()->prepare('INSERT INTO login_attempts (key, at) VALUES (?, ?)')->execute([$key, date('c')]);
}

function strong_enough(string $password): bool
{
    return mb_strlen($password) >= 10 && $password !== TEMP_PASS;
}

/* ------------------------------------------------------------------ uploads */

function save_upload(string $field, string $prefix): string
{
    if (empty($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return '';
    }
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) fail('That file did not upload. Please try again.');
    if ($f['size'] > MAX_UPLOAD)       fail('That file is larger than 8 MB.');

    $allowed = ['pdf' => 'application/pdf', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
                'png' => 'image/png', 'doc' => 'application/msword',
                'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    $ext = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
    if (!isset($allowed[$ext])) fail('Please upload a PDF, image or Word document.');

    $name = $prefix . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . '/' . $name)) {
        fail('The file could not be saved. Please try again.', 500);
    }
    return $name;
}

function stream_upload(string $name): void
{
    $name = basename($name);
    $path = UPLOAD_DIR . '/' . $name;
    if (!is_file($path)) fail('That file is no longer on the server.', 404);
    $types = ['pdf' => 'application/pdf', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
              'png' => 'image/png', 'doc' => 'application/msword',
              'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
    header('Content-Disposition: inline; filename="' . $name . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
}

/* ------------------------------------------------------------ generic CRUD */

const TABLES = [
    'applications'     => ['statuses' => ['new', 'reviewing', 'accepted', 'waitlist', 'placed', 'rejected'],
                           'search'   => ['reference', 'first_name', 'last_name', 'email', 'phone', 'student_number', 'id_number', 'residence']],
    'enquiries'        => ['statuses' => ['new', 'in_progress', 'answered', 'closed'],
                           'search'   => ['name', 'email', 'phone', 'residence', 'message']],
    'orders'           => ['statuses' => ['new', 'paid', 'ready', 'collected', 'cancelled'],
                           'search'   => ['reference', 'name', 'email', 'phone', 'pack']],
    'job_applications' => ['statuses' => ['new', 'reviewing', 'shortlisted', 'appointed', 'declined'],
                           'search'   => ['name', 'email', 'phone', 'role']],
    'subscribers'      => ['statuses' => [], 'search' => ['name', 'email']],
];

function list_rows(string $table): void
{
    require_user();
    $cfg = TABLES[$table];
    $where = [];
    $args  = [];

    $status = trim((string) ($_GET['status'] ?? ''));
    if ($status !== '' && in_array($status, $cfg['statuses'], true)) {
        $where[] = 'status = ?';
        $args[]  = $status;
    }
    $q = trim((string) ($_GET['q'] ?? ''));
    if ($q !== '') {
        $parts = [];
        foreach ($cfg['search'] as $col) {
            $parts[] = "IFNULL($col,'') LIKE ?";
            $args[]  = '%' . $q . '%';
        }
        $where[] = '(' . implode(' OR ', $parts) . ')';
    }
    $sql = "SELECT * FROM $table" . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY id DESC LIMIT 1000';
    $st  = db()->prepare($sql);
    $st->execute($args);
    ok(['rows' => $st->fetchAll()]);
}

function update_row(string $table, int $id): void
{
    $user = require_user();
    $cfg  = TABLES[$table];
    $in   = body();
    $set  = [];
    $args = [];

    if (isset($in['status'])) {
        if (!in_array($in['status'], $cfg['statuses'], true)) fail('That status is not valid.');
        $set[] = 'status = ?';
        $args[] = $in['status'];
    }
    if (isset($in['staff_notes'])) {
        $set[] = 'staff_notes = ?';
        $args[] = field($in, 'staff_notes', false, 4000);
    }
    if (!$set) fail('Nothing to update.');

    $set[] = 'updated_at = ?';
    $args[] = date('c');
    $args[] = $id;

    $st = db()->prepare("UPDATE $table SET " . implode(', ', $set) . ' WHERE id = ?');
    $st->execute($args);
    if ($st->rowCount() === 0) fail('That record no longer exists.', 404);

    audit('update', "$table#$id by {$user['email']}");
    ok(['message' => 'Saved.']);
}

function delete_row(string $table, int $id): void
{
    $user = require_role(['owner', 'manager']);
    $st = db()->prepare("DELETE FROM $table WHERE id = ?");
    $st->execute([$id]);
    if ($st->rowCount() === 0) fail('That record no longer exists.', 404);
    audit('delete', "$table#$id by {$user['email']}");
    ok(['message' => 'Deleted.']);
}

function export_csv(string $table): void
{
    require_user();
    $rows = db()->query("SELECT * FROM $table ORDER BY id DESC")->fetchAll();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="ligcabho-' . $table . '-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    if ($rows) {
        fputcsv($out, array_keys($rows[0]));
        foreach ($rows as $r) fputcsv($out, array_values($r));
    } else {
        fputcsv($out, ['no records']);
    }
    fclose($out);
    exit;
}

/* ------------------------------------------------------------------ routing */

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path   = trim((string) ($_GET['route'] ?? ''), '/');
if ($path === '') {
    $uri  = parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?: '';
    $path = trim(substr($uri, (int) strpos($uri, '/api/') + 5), '/');
}
$seg = $path === '' ? [] : explode('/', $path);
$r0  = $seg[0] ?? '';
$r1  = $seg[1] ?? '';
$r2  = $seg[2] ?? '';

if ($method === 'OPTIONS') ok();

db(); // open and migrate

/* ---- auth ---- */
if ($r0 === 'auth') {
    if ($r1 === 'login' && $method === 'POST') {
        $in    = body();
        $email = email_field($in, 'email');
        $pass  = (string) ($in['password'] ?? '');
        $key   = $email . '|' . client_ip();

        if (throttled($key)) fail('Too many attempts. Please wait 15 minutes and try again.', 429);

        $st = db()->prepare('SELECT * FROM users WHERE email = ? AND active = 1');
        $st->execute([$email]);
        $u = $st->fetch();

        if (!$u || !password_verify($pass, $u['password_hash'])) {
            note_attempt($key);
            audit('login_failed', $email);
            fail('That email address and password do not match.', 401);
        }

        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => (int) $u['id'], 'email' => $u['email']];
        db()->prepare('UPDATE users SET last_login_at = ? WHERE id = ?')->execute([date('c'), $u['id']]);
        db()->prepare('DELETE FROM login_attempts WHERE key = ?')->execute([$key]);
        audit('login', $email);

        ok(['user' => [
            'id' => (int) $u['id'], 'email' => $u['email'], 'name' => $u['name'], 'role' => $u['role'],
            'must_change_password' => (int) $u['must_change_password'],
        ]]);
    }

    if ($r1 === 'me' && $method === 'GET') {
        $u = current_user();
        if (!$u) fail('Not signed in.', 401);
        ok(['user' => $u]);
    }

    if ($r1 === 'logout' && $method === 'POST') {
        audit('logout');
        $_SESSION = [];
        session_destroy();
        ok(['message' => 'Signed out.']);
    }

    if ($r1 === 'password' && $method === 'POST') {
        $u = current_user();
        if (!$u) fail('Please sign in again.', 401);
        $in  = body();
        $cur = (string) ($in['current_password'] ?? '');
        $new = (string) ($in['new_password'] ?? '');

        $st = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
        $st->execute([$u['id']]);
        $hash = (string) $st->fetch()['password_hash'];

        if (!password_verify($cur, $hash)) fail('Your current password is not correct.');
        if (!strong_enough($new)) fail('Choose at least 10 characters, and not the shared temporary password.');

        db()->prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')
            ->execute([password_hash($new, PASSWORD_DEFAULT), $u['id']]);
        audit('password_changed', $u['email']);
        ok(['message' => 'Password updated.']);
    }
    fail('Unknown auth endpoint.', 404);
}

/* ---- public form intake ---- */
if ($method === 'POST' && $r1 === '' && in_array($r0, ['applications', 'enquiries', 'orders', 'job-applications', 'subscribers'], true)) {
    $in = body();

    if ($r0 === 'applications') {
        if (($in['consent'] ?? '') === '') fail('Please confirm the declaration before submitting.');
        $idnum = preg_replace('/\D+/', '', field($in, 'id_number', true, 20)) ?? '';
        if (strlen($idnum) !== 13) fail('A South African ID number is 13 digits.');

        $ref = reference('LIG');
        $st = db()->prepare('INSERT INTO applications
            (reference, first_name, last_name, id_number, student_number, phone, email, gender, level,
             institution, funder, year, residence, room_type, notes, document, status, ip, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $st->execute([
            $ref, field($in, 'first_name', true, 80), field($in, 'last_name', true, 80), $idnum,
            field($in, 'student_number', true, 40), field($in, 'phone', true, 30), email_field($in, 'email'),
            field($in, 'gender', true, 20), field($in, 'level', true, 40), field($in, 'institution', true, 120),
            field($in, 'funder', true, 60), field($in, 'year', true, 10), field($in, 'residence', false, 120),
            field($in, 'room_type', false, 40), field($in, 'notes', false, 4000),
            save_upload('document', 'application'), 'new', client_ip(), date('c'),
        ]);
        audit('application', $ref);
        ok(['message' => 'Application received. Our team will confirm your placement by email or WhatsApp.',
            'reference' => $ref]);
    }

    if ($r0 === 'enquiries') {
        $st = db()->prepare('INSERT INTO enquiries (name, email, phone, topic, residence, message, status, ip, created_at)
                             VALUES (?,?,?,?,?,?,?,?,?)');
        $st->execute([
            field($in, 'name', true, 80), email_field($in, 'email'), field($in, 'phone', false, 30),
            field($in, 'topic', false, 80), field($in, 'residence', false, 120),
            field($in, 'message', true, 4000), 'new', client_ip(), date('c'),
        ]);
        audit('enquiry');
        ok(['message' => 'Thank you — your message is with the team and we will get back to you.']);
    }

    if ($r0 === 'orders') {
        $ref = reference('PACK');
        $st = db()->prepare('INSERT INTO orders (reference, pack, name, email, phone, status, created_at)
                             VALUES (?,?,?,?,?,?,?)');
        $st->execute([$ref, field($in, 'pack', true, 80), field($in, 'name', true, 80),
                      email_field($in, 'email'), field($in, 'phone', true, 30), 'new', date('c')]);
        audit('order', $ref);
        ok(['message' => 'Order received. We will confirm payment and collection with you.', 'reference' => $ref]);
    }

    if ($r0 === 'job-applications') {
        $st = db()->prepare('INSERT INTO job_applications (name, email, phone, role, message, document, status, created_at)
                             VALUES (?,?,?,?,?,?,?,?)');
        $st->execute([field($in, 'name', true, 80), email_field($in, 'email'), field($in, 'phone', true, 30),
                      field($in, 'role', true, 120), field($in, 'message', false, 4000),
                      save_upload('document', 'cv'), 'new', date('c')]);
        audit('job_application');
        ok(['message' => 'Application received. We contact shortlisted candidates directly.']);
    }

    if ($r0 === 'subscribers') {
        $email = email_field($in, 'email');
        $st = db()->prepare('INSERT OR IGNORE INTO subscribers (name, email, created_at) VALUES (?,?,?)');
        $st->execute([field($in, 'name', false, 80), $email, date('c')]);
        ok(['message' => 'You are on the list. Welcome to Ligcabho.']);
    }
}

/* ---- staff reads and writes ---- */
$table_of = ['applications' => 'applications', 'enquiries' => 'enquiries', 'orders' => 'orders',
             'job-applications' => 'job_applications', 'subscribers' => 'subscribers'];

if (isset($table_of[$r0])) {
    $table = $table_of[$r0];

    if ($r1 === 'export' && $method === 'GET') export_csv($table);
    if ($r1 === '' && $method === 'GET')       list_rows($table);
    if ($r1 !== '' && ctype_digit($r1)) {
        if ($method === 'PATCH' || $method === 'POST') update_row($table, (int) $r1);
        if ($method === 'DELETE')                      delete_row($table, (int) $r1);
    }
    fail('Unsupported request for ' . $r0 . '.', 405);
}

/* ---- file downloads ---- */
if ($r0 === 'files' && $method === 'GET' && $r1 !== '') {
    require_user();
    stream_upload($r1);
}

/* ---- dashboard stats ---- */
if ($r0 === 'stats' && $method === 'GET') {
    require_user();
    $pdo = db();
    $count = function (string $sql, array $a = []) use ($pdo): int {
        $st = $pdo->prepare($sql);
        $st->execute($a);
        return (int) $st->fetch()['n'];
    };
    $since = date('c', strtotime('-7 days'));
    $byStatus = [];
    foreach ($pdo->query("SELECT status, COUNT(*) n FROM applications GROUP BY status") as $row) {
        $byStatus[$row['status']] = (int) $row['n'];
    }
    $byResidence = $pdo->query("SELECT IFNULL(NULLIF(residence,''),'No preference') AS residence, COUNT(*) n
                                FROM applications GROUP BY residence ORDER BY n DESC LIMIT 10")->fetchAll();
    ok(['stats' => [
        'applications'       => $count('SELECT COUNT(*) n FROM applications'),
        'applications_new'   => $count("SELECT COUNT(*) n FROM applications WHERE status='new'"),
        'applications_week'  => $count('SELECT COUNT(*) n FROM applications WHERE created_at >= ?', [$since]),
        'enquiries'          => $count('SELECT COUNT(*) n FROM enquiries'),
        'enquiries_open'     => $count("SELECT COUNT(*) n FROM enquiries WHERE status IN ('new','in_progress')"),
        'orders'             => $count('SELECT COUNT(*) n FROM orders'),
        'job_applications'   => $count('SELECT COUNT(*) n FROM job_applications'),
        'subscribers'        => $count('SELECT COUNT(*) n FROM subscribers'),
        'by_status'          => $byStatus,
        'by_residence'       => $byResidence,
        'recent'             => $pdo->query('SELECT reference, first_name, last_name, residence, status, created_at
                                             FROM applications ORDER BY id DESC LIMIT 8')->fetchAll(),
    ]]);
}

/* ---- users (owner only) ---- */
if ($r0 === 'users') {
    if ($method === 'GET' && $r1 === '') {
        require_role(['owner']);
        ok(['rows' => db()->query('SELECT id, email, name, role, active, must_change_password, last_login_at, created_at
                                   FROM users ORDER BY id')->fetchAll()]);
    }
    if ($method === 'POST' && $r1 === '') {
        require_role(['owner']);
        $in    = body();
        $email = email_field($in, 'email');
        $name  = field($in, 'name', true, 80);
        $role  = field($in, 'role', true, 20);
        if (!in_array($role, ['owner', 'manager', 'staff'], true)) fail('Choose a valid role.');
        try {
            db()->prepare('INSERT INTO users (email, name, role, password_hash, must_change_password, active, created_at)
                           VALUES (?,?,?,?,1,1,?)')
               ->execute([$email, $name, $role, password_hash(TEMP_PASS, PASSWORD_DEFAULT), date('c')]);
        } catch (Throwable $e) {
            fail('That email address already has an account.');
        }
        audit('user_created', $email);
        ok(['message' => 'User added with the shared temporary password. They must change it at first sign-in.']);
    }
    if (ctype_digit($r1)) {
        $me = require_role(['owner']);
        $id = (int) $r1;

        if ($r2 === 'reset' && $method === 'POST') {
            db()->prepare('UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?')
               ->execute([password_hash(TEMP_PASS, PASSWORD_DEFAULT), $id]);
            audit('user_password_reset', 'user#' . $id);
            ok(['message' => 'Password reset to the temporary password.']);
        }
        if ($method === 'PATCH' || $method === 'POST') {
            $in = body();
            $set = [];
            $args = [];
            if (isset($in['role'])) {
                if (!in_array($in['role'], ['owner', 'manager', 'staff'], true)) fail('Choose a valid role.');
                if ($id === (int) $me['id']) fail('You cannot change your own role.');
                $set[] = 'role = ?';
                $args[] = $in['role'];
            }
            if (isset($in['active'])) {
                if ($id === (int) $me['id']) fail('You cannot deactivate your own account.');
                $set[] = 'active = ?';
                $args[] = ((int) $in['active']) === 1 ? 1 : 0;
            }
            if (isset($in['name'])) {
                $set[] = 'name = ?';
                $args[] = field($in, 'name', true, 80);
            }
            if (!$set) fail('Nothing to update.');
            $args[] = $id;
            db()->prepare('UPDATE users SET ' . implode(', ', $set) . ' WHERE id = ?')->execute($args);
            audit('user_updated', 'user#' . $id);
            ok(['message' => 'Saved.']);
        }
        if ($method === 'DELETE') {
            if ($id === (int) $me['id']) fail('You cannot delete your own account.');
            db()->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
            audit('user_deleted', 'user#' . $id);
            ok(['message' => 'User removed.']);
        }
    }
    fail('Unsupported request for users.', 405);
}

/* ---- audit log (owner only) ---- */
if ($r0 === 'audit' && $method === 'GET') {
    require_role(['owner']);
    ok(['rows' => db()->query('SELECT * FROM audit_log ORDER BY id DESC LIMIT 300')->fetchAll()]);
}

fail('Unknown endpoint.', 404);
