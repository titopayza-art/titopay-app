<?php
/**
 * Ligcabho documents.
 *
 * Builds the PDFs a tenant receives once their lease is complete: the signed
 * lease agreement and the house rules. The clause text mirrors
 * assets/js/lease.js and house-rules.html, so the downloaded copy reads the
 * same as the copy the tenant signed on screen.
 */
declare(strict_types=1);
require_once __DIR__ . '/pdf.php';

function doc_day(?string $v): string
{
    if (!$v) return 'not stated';
    $ts = strtotime($v);
    return $ts ? date('d F Y', $ts) : $v;
}

function doc_stamp(?string $v): string
{
    if (!$v) return '';
    $ts = strtotime($v);
    return $ts ? date('d M Y \a\t H:i', $ts) . ' (SAST +2)' : $v;
}

function doc_money(?string $v): string
{
    $v = trim((string) $v);
    return $v === '' ? 'not stated' : 'R' . ltrim($v, 'Rr ');
}

function doc_val(?string $v): string
{
    $v = trim((string) $v);
    return $v === '' ? 'not stated' : $v;
}

/** The lease clauses, in the same order and wording as the on-screen lease. */
function lease_clauses(array $l, array $t): array
{
    $rent     = doc_money($l['monthly_rent'] ?? '');
    $deposit  = doc_money($l['deposit'] ?? '');
    $adminFee = doc_money($l['admin_fee'] ?? '');
    $house    = doc_val($l['residence'] ?? '');

    return [
        ['Letting and occupation',
         "The landlord lets to the tenant the room described above, at $house, for residential use by the tenant "
         . "alone. The room may not be sub-let, shared with anyone who is not a registered tenant, or used for any "
         . "business."],

        ['Period',
         'The lease runs from ' . doc_day($l['commencement_date'] ?? '') . ' to ' . doc_day($l['end_date'] ?? '')
         . '. It does not renew automatically: a new agreement is signed for each academic year.'],

        ['Rent',
         "Rent is $rent per month, payable monthly in advance, on or before the first day of each month, into the "
         . "landlord's account. The tenant uses their name and ID number as the payment reference. Rent remains due "
         . "whether or not the tenant is in residence during the period, and late payment may attract interest and "
         . "collection costs."],

        ['Funding',
         'Where the tenant is funded by NSFAS, a bursary or a sponsor, the tenant remains responsible for the rent '
         . 'if the funder does not pay, pays late or withdraws funding. The tenant must tell the landlord in writing '
         . 'as soon as their funding status changes.'],

        ['Deposit',
         "A deposit of $deposit is payable before occupation. It is held as security for damage, unpaid rent and "
         . "charges. It is refunded after the room has been inspected at vacate, less any amounts properly owing, and "
         . "after the tenant has been given a written account of any deductions."],

        ['Administration fee',
         "The administration fee of $adminFee is payable to reserve the room. It is not refundable and is not rent."],

        ['House rules',
         'The Ligcabho house rules form part of this agreement and are binding on the tenant. They cover water and '
         . 'electricity use, consideration of others, care of the building and rooms, smoking, drugs and alcohol, '
         . 'medical conditions, security, visitors, pregnancy, parking and compliance. A copy is issued with this '
         . 'lease and is published on the website.'],

        ['Visitors',
         'Visitors sign in at the front desk. A scheduled sleepover is charged at R135 per person with proof of '
         . "payment; an unscheduled visitor is charged at R200 per visitor to the tenant's rental account. No visitor "
         . "may occupy the room in the tenant's absence."],

        ['Maintenance and inspections',
         'The tenant reports all maintenance in the book at the front desk. The landlord maintains the building and '
         . 'attends to logged items within the published turnaround times. Rooms are inspected twice a month; damage '
         . "found on inspection is charged to the tenant's account and repaired once paid. The tenant completes the "
         . 'room occupation inspection list within 48 hours of receiving this lease.'],

        ['Services and interruptions',
         'Water, electricity, Wi-Fi and security services are provided as described for the residence. The landlord '
         . 'is not liable for interruptions outside its control, including municipal outages and load shedding, but '
         . 'will restore services as soon as reasonably possible.'],

        ['Vacating',
         'The tenant collects a vacate note from the office 24 hours before vacating. A note is only issued when the '
         . 'account is paid in full. At year end the room is inspected, damages are charged, and any refund is paid '
         . 'after deductions.'],

        ['Breach and cancellation',
         'If the tenant breaches this agreement and does not remedy the breach within seven days of written notice, '
         . 'the landlord may cancel the lease, reclaim the room and recover any loss. Serious breaches of the '
         . "security, drug or conduct rules may lead to immediate cancellation, and the tenant's funder may be "
         . 'informed.'],

        ['Liability',
         'The tenant occupies the room and uses the common areas at their own risk. The landlord is not liable for '
         . "loss of or damage to the tenant's property except where the loss is caused by the landlord's own gross "
         . 'negligence. Tenants are encouraged to insure their belongings.'],

        ['Personal information',
         "The landlord processes the tenant's personal information to administer this lease, in line with POPIA. "
         . "Information is shared with the tenant's funder or institution only where that is needed to confirm "
         . 'placement or payment.'],

        ['Whole agreement',
         'This agreement, together with the house rules, is the whole agreement between the parties. Any variation '
         . "must be in writing and signed by both. Domicile addresses are the landlord's address at "
         . doc_val($t['landlord_address'] ?? '') . " and the tenant's home address given below."],
    ];
}

/** The signed (or unsigned) lease agreement as a PDF. */
function lease_pdf(array $l, array $terms, array $site): string
{
    $tenant = trim(($l['tenant_name'] ?? '') . ' ' . ($l['tenant_surname'] ?? ''));
    $pdf = new Pdf([
        'title'  => 'Lease Agreement - ' . $tenant,
        'footer' => ($site['name'] ?? 'Ligcabho') . '   ' . ($site['phone'] ?? ''),
    ]);

    $pdf->title('Lease Agreement',
        doc_val($terms['landlord_entity'] ?? '') . ' and ' . $tenant);

    $pdf->heading('Parties');
    $pdf->row('Landlord', doc_val($terms['landlord_entity'] ?? ''));
    $pdf->row('Landlord address', doc_val($terms['landlord_address'] ?? ''));
    $pdf->row('Landlord email', doc_val($terms['landlord_email'] ?? ''));
    $pdf->row('Tenant', $tenant);
    $pdf->row('Tenant ID number', doc_val($l['tenant_id_number'] ?? ''));
    $pdf->row('Tenant phone', doc_val($l['tenant_phone'] ?? ''));
    $pdf->row('Tenant email', doc_val($l['tenant_email'] ?? ''));
    if (!empty($l['student_number'])) $pdf->row('Student number', $l['student_number']);
    if (!empty($l['institution']))    $pdf->row('Institution', $l['institution']);
    if (!empty($l['course']))         $pdf->row('Course', $l['course']);

    $pdf->heading('The room');
    $pdf->row('Residence', doc_val($l['residence'] ?? ''));
    $pdf->row('Room number', doc_val($l['room_number'] ?? ''));
    $pdf->row('Room type', doc_val($l['room_type'] ?? ''));
    $pdf->row('Occupation from', doc_day($l['commencement_date'] ?? ''));
    $pdf->row('Until', doc_day($l['end_date'] ?? ''));
    $pdf->row('Monthly rent', doc_money($l['monthly_rent'] ?? ''));
    $pdf->row('Deposit', doc_money($l['deposit'] ?? ''));
    $pdf->row('Administration fee', doc_money($l['admin_fee'] ?? ''));
    if (!empty($l['funder'])) $pdf->row('Funder', $l['funder']);

    $pdf->heading('Terms and conditions');
    foreach (lease_clauses($l, $terms) as $i => $c) {
        $pdf->text(($i + 1) . '. ' . $c[0], 10.5, true);
        $pdf->text($c[1], 9.5);
        $pdf->space(4);
    }

    if (!empty($l['special_conditions'])) {
        $pdf->heading('Special conditions');
        $pdf->text($l['special_conditions'], 9.5);
    }

    $pdf->heading('Tenant details given on signature');
    $pdf->row('Home address', doc_val($l['home_address'] ?? ''));
    $pdf->row('Next of kin', doc_val($l['kin_name'] ?? ''));
    $pdf->row('Kin contact', doc_val($l['kin_contact'] ?? ''));

    $pdf->heading('Signatures');
    $pdf->text('This lease was signed electronically. The signature, the date, the time and the IP address it was '
        . 'signed from are recorded against this agreement, and an electronic signature is as binding as a signature '
        . 'on paper.', 9);
    $pdf->space(6);
    $pdf->signature('Tenant', doc_val($l['tenant_signed_name'] ?? $tenant), doc_stamp($l['tenant_signed_at'] ?? ''));
    $pdf->signature('For ' . doc_val($terms['landlord_entity'] ?? 'the landlord'),
        doc_val($l['landlord_signed_name'] ?? 'Awaiting counter-signature'),
        doc_stamp($l['landlord_signed_at'] ?? ''));

    if (!empty($l['tenant_sign_ip'])) {
        $pdf->space(8);
        $pdf->text('Signed from IP ' . $l['tenant_sign_ip'] . '. Reference ' . ($l['token'] ?? ''), 8);
    }

    return $pdf->output();
}

/** The eleven house rule policies as a PDF. */
function house_rules_pdf(array $site): string
{
    $rules = [
        ['Water and electricity consumption',
         'Water and electricity are supplied for reasonable residential use. Wastage, unattended taps, heaters left '
         . "running and tampering with meters or the backup supply are charged to the student's account."],
        ['Consideration of others',
         'A residence is a shared home. Noise is kept down at all times and strictly after 22h00, and behaviour that '
         . "disturbs other students' rest or study is a breach of the lease."],
        ['Care of the building, common areas and rooms',
         'Students keep their rooms clean and leave common areas as they would like to find them. Damage and '
         . "vandalism are charged to the responsible student's account and repaired once paid."],
        ['Smoking, drugs and alcohol policy',
         'No smoking inside rooms, passages or common areas. Illegal substances are prohibited on all Ligcabho '
         . 'property, and intoxicated conduct that endangers or disturbs others is a breach of the lease.'],
        ['Medical conditions and disabilities',
         'Students must declare medical conditions, allergies and disabilities on application so that the residence '
         . 'can place them appropriately and respond correctly in an emergency.'],
        ['Security and safety policy',
         'Access control, gate and door discipline, and the instructions of security personnel are binding on every '
         . 'student. Keys, tags and access codes may not be shared or duplicated.'],
        ['Visitors',
         'Visitors sign in at the front desk. Scheduled sleepovers are charged at R135 per person with proof of '
         . "payment; unscheduled sleepovers are charged at R200 per visitor to the student's rental account."],
        ['General',
         'House comms, notices in the lobby and instructions from the house warden form part of these rules. '
         . 'Furniture may not be removed from rooms or common areas.'],
        ['Pregnancy policy',
         'A pregnant student must notify the manager so that suitable arrangements can be made. Residences are not '
         . 'equipped as family accommodation and infants may not be housed in student rooms.'],
        ['Student parking regulations',
         "Parking is available at selected residences, by allocation only, and vehicles are parked at the owner's "
         . 'risk. Unroadworthy or unlicensed vehicles may not be stored on the premises.'],
        ['Compliance - failure to observe',
         "Failure to observe these rules leads to a written warning, a charge to the student's account, and in "
         . 'serious or repeated cases cancellation of the lease and the funder being informed.'],
    ];

    $pdf = new Pdf([
        'title'  => 'House Rules',
        'footer' => ($site['name'] ?? 'Ligcabho') . '   ' . ($site['phone'] ?? ''),
    ]);
    $pdf->title('House Rules', ($site['name'] ?? '') . ' - issued with every lease agreement');
    $pdf->text('These rules form part of your lease agreement and are binding on every student in residence. Keep '
        . 'this copy: the front desk works from the same document.', 9.5);

    foreach ($rules as $i => $r) {
        $pdf->text(($i + 1) . '. ' . $r[0], 10.5, true);
        $pdf->text($r[1], 9.5);
        $pdf->space(4);
    }

    $pdf->heading('Maintenance turnaround');
    $pdf->bullet('12 hours: water wastage (not flood related), globes in student rooms or critical areas, toilets, '
        . 'locks, showers that are not usable, stoves.');
    $pdf->bullet('36 hours: carpets, tiles, hydroboilers, basins, taps, flush masters, shower doors.');
    $pdf->bullet('Items vandalised by students are not subject to these turnaround times.');
    $pdf->bullet('Matters recorded on a Friday after 15h00 may only be attended to on the Monday, unless it is an '
        . 'emergency. A standby team attends to emergencies over weekends.');

    $pdf->heading('Who to call');
    $pdf->row('Ligcabho emergency line', '071 640 1574 (24 hours)');
    $pdf->row('Head office', doc_val($site['phone'] ?? ''));
    $pdf->row('Police', '10111');
    $pdf->row('Ambulance and fire', '10177');

    return $pdf->output();
}
