/**
 * Ligcabho application assistant.
 *
 * A scripted chat that collects an application and posts it to the same API
 * the form uses. It answers common questions along the way, and never claims
 * to be a person.
 */
(function () {
  'use strict';

  var API = window.LIGCABHO_API_BASE || 'api/';
  var STORE = 'ligcabho.chat';

  var INSTITUTIONS = [
    'University of Mpumalanga (UMP)',
    'Tshwane University of Technology (TUT)',
    'Ehlanzeni TVET College',
    'Eduvos',
    'University of Johannesburg (UJ)',
    'Unigrad College',
    'Other private college'
  ];

  var RESIDENCES = (window.LIGCABHO_RESIDENCES || []).map(function (r) { return r.name; });
  if (!RESIDENCES.length) RESIDENCES = ['No preference — place me'];

  /* Quick answers the assistant can give without leaving the flow. */
  var FAQS = [
    { k: ['nsfas', 'funding', 'fund', 'bursary'],
      a: 'Yes — we take NSFAS funded students, bursary holders and cash paying students at every residence.' },
    { k: ['price', 'cost', 'how much', 'rent', 'fee'],
      a: 'Rent depends on the residence and whether you take a single or a sharing room. Finish the application and ' +
         'the team will confirm the exact rate for the house you are placed in, or call 013 752 4161.' },
    { k: ['wifi', 'internet', 'data'],
      a: 'Every residence has Wi-Fi. Vouchers are issued when your lease is signed, and again at the start of the second term.' },
    { k: ['security', 'safe', 'safety'],
      a: 'Access control and a security service provider at every house, with armed response at 48 Mataffin Hill and ' +
         'selected residences. Emergency numbers are displayed in each building lobby.' },
    { k: ['pool', 'swim'],
      a: 'There are pools at 1 Silver Oak, 23 Dolomiet, 48 Mataffin Hill and 01 Penny Street.' },
    { k: ['transport', 'shuttle', 'bus', 'far', 'distance'],
      a: 'Most houses are within walking distance of campus; the rest sit on CityBus or campus shuttle routes.' },
    { k: ['visitor', 'sleepover', 'guest'],
      a: 'Scheduled sleepovers are R135 per person with proof of payment. Unscheduled visitors are R200, charged to ' +
         'your rental account.' },
    { k: ['bank', 'account', 'pay', 'payment', 'deposit'],
      a: 'FNB, Ligcabho Properties, business account 62653880552. Use your name and ID number as the reference.' },
    { k: ['human', 'person', 'agent', 'call', 'whatsapp'],
      a: 'Of course — call 013 752 4161 during office hours, or WhatsApp 071 640 1574 any time.' }
  ];

  var STEPS = [
    { key: 'first_name', ask: 'Great, let us get you a room. What is your first name?',
      check: function (v) { return v.length >= 2 || 'Please type your first name.'; } },

    { key: 'last_name', ask: function (d) { return 'Thanks ' + d.first_name + '. And your surname?'; },
      check: function (v) { return v.length >= 2 || 'Please type your surname.'; } },

    { key: 'id_number', ask: 'What is your South African ID number? (13 digits)',
      check: function (v) {
        var id = v.replace(/\D/g, '');
        if (id.length !== 13) return 'A South African ID number is 13 digits.';
        return validSaId(id) || 'That ID number does not check out — please read it off your ID and try again.';
      },
      clean: function (v) { return v.replace(/\D/g, ''); } },

    { key: 'student_number', ask: 'Your student number? If you do not have one yet, type skip.', skippable: true },

    { key: 'gender', ask: 'Rooms are allocated single gender. Which should I put you down for?',
      options: ['Male', 'Female'] },

    { key: 'phone', ask: 'What is the best number to reach you on?',
      check: function (v) {
        return v.replace(/\D/g, '').length >= 9 || 'That number looks short — please include the dialling code.';
      } },

    { key: 'email', ask: 'And your email address?',
      check: function (v) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v) || 'That email address does not look right.'; } },

    { key: 'level_of_study', ask: 'What level are you studying at?',
      options: ['First year', 'Second year', 'Third year', 'Fourth year', 'Postgraduate', 'Other'] },

    { key: 'institution', ask: 'Where are you studying?', options: INSTITUTIONS, allowFree: true },

    { key: 'funder', ask: 'Who is paying your fees?',
      options: ['NSFAS', 'Bursary', 'Cash paying / self funded', 'Employer / sponsor', 'Other'] },

    { key: 'year_applying', ask: 'Which year are you applying for?', options: ['2027', '2028'] },

    { key: 'residence', ask: 'Which residence would you like? If you are not sure, choose "No preference" and we will ' +
        'place you at a house accredited for your institution.',
      options: ['No preference — place me'].concat(RESIDENCES), allowFree: true },

    { key: 'room_type', ask: 'A single is your own room. Sharing is two students to a room and costs less. Which would you prefer?',
      options: ['Single room', 'Sharing room', 'No preference'] },

    { key: 'notes', ask: 'Anything else we should know — accessibility needs, a move-in date, sharing with a friend? Type skip if not.',
      skippable: true }
  ];


  /** A South African ID number: 13 digits with the Luhn check digit. */
  function validSaId(v) {
    var id = String(v || '').replace(/\D/g, '');
    if (!/^\d{13}$/.test(id)) return false;
    var sum = 0;
    for (var i = 0; i < 13; i++) {
      var d = Number(id[i]);
      if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
      sum += d;
    }
    return sum % 10 === 0;
  }

  var state = { open: false, step: -1, data: {}, key: null, busy: false, greeted: false, log: [], queue: [] };

  /* ------------------------------ plumbing ------------------------------ */
  function sessionKey() {
    if (state.key) return state.key;
    try {
      state.key = sessionStorage.getItem(STORE);
    } catch (e) { /* private mode */ }
    if (!state.key) {
      state.key = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      try { sessionStorage.setItem(STORE, state.key); } catch (e) { /* ignore */ }
    }
    return state.key;
  }

  function flush(outcome) {
    if (!state.log.length && !outcome) return;
    var messages = state.log.splice(0, state.log.length);
    fetch(API + 'chat/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ session_key: sessionKey(), messages: messages, outcome: outcome })
    }).catch(function () { /* logging is best effort */ });
  }

  /* --------------------------------- UI --------------------------------- */
  var el = {};

  function build() {
    var wrap = document.createElement('div');
    wrap.className = 'chat';
    wrap.innerHTML =
      '<button class="chat__launch" type="button" aria-expanded="false" aria-controls="chat-panel">' +
        '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" ' +
        'stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-8 8H7l-4 3 1.2-4.2A8 8 0 1 1 21 12z"/>' +
        '</svg><span>Apply by chat</span></button>' +
      '<section class="chat__panel" id="chat-panel" hidden aria-label="Ligcabho application assistant">' +
        '<header class="chat__head">' +
          '<div><strong>Ligcabho assistant</strong><span>Applications for 2027</span></div>' +
          '<button class="chat__close" type="button" aria-label="Close chat">&times;</button>' +
        '</header>' +
        '<div class="chat__log" id="chat-log" role="log" aria-live="polite"></div>' +
        '<div class="chat__options" id="chat-options"></div>' +
        '<form class="chat__form" id="chat-form">' +
          '<label class="visually-hidden" for="chat-input">Your message</label>' +
          '<input id="chat-input" autocomplete="off" placeholder="Type your answer…">' +
          '<button class="chat__send" type="submit" aria-label="Send">&#8594;</button>' +
        '</form>' +
        '<p class="chat__note">You are chatting with an automated assistant. For a person, call 013 752 4161.</p>' +
      '</section>';
    document.body.appendChild(wrap);

    el.root = wrap;
    el.launch = wrap.querySelector('.chat__launch');
    el.panel = wrap.querySelector('.chat__panel');
    el.log = wrap.querySelector('#chat-log');
    el.options = wrap.querySelector('#chat-options');
    el.form = wrap.querySelector('#chat-form');
    el.input = wrap.querySelector('#chat-input');

    el.launch.addEventListener('click', toggle);
    wrap.querySelector('.chat__close').addEventListener('click', toggle);
    el.form.addEventListener('submit', function (e) {
      e.preventDefault();
      var v = el.input.value.trim();
      if (!v) return;
      el.input.value = '';
      handle(v);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && state.open) toggle();
    });
  }

  function toggle() {
    state.open = !state.open;
    el.panel.hidden = !state.open;
    el.launch.setAttribute('aria-expanded', String(state.open));
    el.root.classList.toggle('is-open', state.open);
    if (state.open) {
      if (!state.greeted) greet();
      setTimeout(function () { el.input.focus(); }, 80);
    } else {
      flush(state.step >= STEPS.length ? 'applied' : (state.step > -1 ? 'abandoned' : 'open'));
    }
  }

  function bubble(role, text) {
    var p = document.createElement('div');
    p.className = 'chat__msg chat__msg--' + role;
    p.textContent = text;
    el.log.appendChild(p);
    el.log.scrollTop = el.log.scrollHeight;
    state.log.push({ role: role === 'bot' ? 'bot' : 'user', text: text });
  }

  function say(text, delay) {
    state.busy = true;
    var typing = document.createElement('div');
    typing.className = 'chat__msg chat__msg--bot chat__typing';
    typing.innerHTML = '<span></span><span></span><span></span>';
    el.log.appendChild(typing);
    el.log.scrollTop = el.log.scrollHeight;
    setTimeout(function () {
      typing.remove();
      bubble('bot', text);
      state.busy = false;
      if (state.queue.length) {
        var next = state.queue.shift();
        setTimeout(function () { handle(next); }, 60);
      }
    }, delay || Math.min(900, 260 + text.length * 8));
  }

  function options(list) {
    el.options.innerHTML = '';
    (list || []).forEach(function (o) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'chat__chip';
      b.textContent = o;
      b.addEventListener('click', function () { handle(o); });
      el.options.appendChild(b);
    });
  }

  /* ------------------------------- the flow ------------------------------ */
  function greet() {
    state.greeted = true;
    say("Hi! I am the Ligcabho assistant. I can answer questions about our residences, or take your application for " +
        "2027 right here — it takes about two minutes.", 500);
    setTimeout(function () {
      say('What would you like to do?');
      options(['Apply for a room', 'Ask a question', 'Talk to a person']);
    }, 700);
  }

  function faqAnswer(text) {
    var t = text.toLowerCase();
    for (var i = 0; i < FAQS.length; i++) {
      for (var j = 0; j < FAQS[i].k.length; j++) {
        if (t.indexOf(FAQS[i].k[j]) !== -1) return FAQS[i].a;
      }
    }
    return null;
  }

  function handle(text) {
    // Students type faster than the assistant answers: hold the answer rather
    // than losing it, and deal with it as soon as the reply lands.
    if (state.busy) {
      state.queue.push(text);
      return;
    }
    bubble('user', text);
    options([]);

    /* Before the application starts. */
    if (state.step === -1) {
      if (/^apply/i.test(text)) return start();
      if (/person|human|call|whatsapp/i.test(text)) {
        say('No problem. Call 013 752 4161 during office hours, or WhatsApp 071 640 1574 — that line is answered ' +
            'around the clock. I can still take your application here whenever you are ready.');
        flush('handoff');
        setTimeout(function () { options(['Apply for a room']); }, 900);
        return;
      }
      var a = faqAnswer(text);
      say(a || 'I can help with rooms, funding, security, Wi-Fi, visitors and payments — or take your application. ' +
              'What would you like to know?');
      setTimeout(function () { options(['Apply for a room', 'Talk to a person']); }, 900);
      return;
    }

    /* Mid-application: answer the question, then re-ask the step. */
    if (state.step < STEPS.length) {
      var step = STEPS[state.step];
      var value = text.trim();

      if (/^(skip|none|no)$/i.test(value) && step.skippable) {
        state.data[step.key] = '';
        return next();
      }
      if (step.clean) value = step.clean(value);
      if (step.check) {
        var verdict = step.check(value);
        if (verdict !== true) {
          say(verdict);
          setTimeout(function () { ask(state.step); }, 800);
          return;
        }
      }
      state.data[step.key] = value;
      return next();
    }
  }

  function start() {
    state.step = 0;
    say('Perfect. I will ask a few questions, and you can type skip on anything optional.', 500);
    setTimeout(function () { ask(0); }, 800);
  }

  function ask(i) {
    var step = STEPS[i];
    var q = typeof step.ask === 'function' ? step.ask(state.data) : step.ask;
    say(q);
    setTimeout(function () {
      options(step.options || (step.skippable ? ['Skip'] : []));
      el.input.placeholder = step.options && !step.allowFree ? 'Choose above, or type your answer…' : 'Type your answer…';
    }, 500);
  }

  function next() {
    state.step++;
    if (state.step < STEPS.length) {
      setTimeout(function () { ask(state.step); }, 350);
      return;
    }
    submit();
  }

  function submit() {
    say('Thank you. Sending your application now…', 400);
    var payload = {
      first_name: state.data.first_name,
      last_name: state.data.last_name,
      id_number: state.data.id_number,
      student_number: state.data.student_number || '',
      gender: state.data.gender || '',
      phone: state.data.phone,
      email: state.data.email,
      level_of_study: state.data.level_of_study || '',
      institution: state.data.institution || '',
      funder: state.data.funder || '',
      year_applying: state.data.year_applying || '',
      residence: /no preference/i.test(state.data.residence || '') ? '' : (state.data.residence || ''),
      room_type: state.data.room_type || '',
      notes: state.data.notes || '',
      source: 'chat',
      consent: 'yes'
    };

    fetch(API + 'applications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(payload)
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok || j.ok === false) throw new Error(j.error || 'Something went wrong. Please try again.');
        return j;
      });
    }).then(function (res) {
      say('Done! Your reference is ' + res.ref + '. We have emailed you a confirmation.', 500);
      setTimeout(function () {
        say('If you have a proof of payment or funding letter, WhatsApp it to 071 640 1574 with your reference and ' +
            'we will finish your placement.');
        options(['Open WhatsApp', 'Done']);
      }, 1000);
      state.step = STEPS.length + 1;
      flush('applied');
      el.form.addEventListener('submit', function stop(e) { e.preventDefault(); }, { once: true });
      el.options.addEventListener('click', function (e) {
        if (e.target.textContent === 'Open WhatsApp') {
          window.open('https://wa.me/27716401574?text=Hi%20Ligcabho,%20my%20application%20reference%20is%20' +
            encodeURIComponent(res.ref), '_blank', 'noopener');
        }
      });
    }).catch(function (err) {
      say('I could not send that: ' + err.message);
      setTimeout(function () {
        say('You can also apply on the application form, or WhatsApp 071 640 1574 and we will take it down for you.');
        options(['Try again']);
        state.step = STEPS.length - 1;
      }, 900);
    });
  }

  /* -------------------------------- start -------------------------------- */
  if (!document.body.hasAttribute('data-no-chat')) {
    build();
    window.addEventListener('beforeunload', function () {
      if (state.log.length) flush(state.step >= STEPS.length ? 'applied' : 'abandoned');
    });
    // Any "apply by chat" link on the page opens the assistant.
    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-open-chat]');
      if (!t) return;
      e.preventDefault();
      if (!state.open) toggle();
    });
  }
})();
