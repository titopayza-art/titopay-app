/**
 * Ligcabho lease agreement, tenant view.
 *
 * Opens a lease by its token (lease.html?t=…), renders it, and takes the
 * tenant's signature. The signature is drawn or typed, flattened to a PNG
 * and posted to the API, which records it with the time and IP address.
 */
(function () {
  'use strict';

  var API = 'api/';
  var $ = function (s, r) { return (r || document).querySelector(s); };

  var token = new URLSearchParams(location.search).get('t') || '';
  var lease = null;
  var terms = null;
  var sigMode = 'draw';

  function esc(t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function rands(v) {
    var n = String(v == null ? '' : v).replace(/[^\d.]/g, '');
    return n === '' ? '—' : 'R' + Number(n).toLocaleString('en-ZA');
  }

  function dl(pairs) {
    return pairs.filter(function (p) { return p[1]; })
      .map(function (p) { return '<dt>' + esc(p[0]) + '</dt><dd>' + esc(p[1]) + '</dd>'; }).join('');
  }

  function fmtDate(iso) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString('en-ZA', { day: '2-digit', month: 'long', year: 'numeric' }) +
      ' at ' + d.toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' });
  }

  function problem(message) {
    $('#state').innerHTML = '<h1>We could not open that lease</h1><p>' + esc(message) + '</p>' +
      '<p><a class="btn btn--primary" href="index.html">Back to the website</a> ' +
      '<a class="btn btn--ghost" href="https://wa.me/27716401574">WhatsApp us</a></p>';
  }

  /* ------------------------------ the clauses ---------------------------- */
  function clauses(l, t) {
    var rent = rands(l.monthly_rent);
    var items = [
      ['Letting and occupation',
       'The landlord lets to the tenant the room described above, at ' + esc(l.residence || 'the residence named above') +
       ', for residential use by the tenant alone. The room may not be sub-let, shared with anyone who is not a ' +
       'registered tenant, or used for any business.'],

      ['Period',
       'The lease runs from ' + esc(l.commencement_date || 'the commencement date') + ' to ' +
       esc(l.end_date || 'the end date') + '. It does not renew automatically: a new agreement is signed for each ' +
       'academic year.'],

      ['Rent',
       'Rent is ' + rent + ' per month, payable monthly in advance, on or before the first day of each month, into ' +
       'the landlord\'s account. The tenant uses their name and ID number as the payment reference. Rent remains due ' +
       'whether or not the tenant is in residence during the period, and late payment may attract interest and ' +
       'collection costs.'],

      ['Funding',
       'Where the tenant is funded by NSFAS, a bursary or a sponsor, the tenant remains responsible for the rent if ' +
       'the funder does not pay, pays late or withdraws funding. The tenant must tell the landlord in writing as soon ' +
       'as their funding status changes.'],

      ['Deposit',
       'A deposit of ' + rands(l.deposit) + ' is payable before occupation. It is held as security for damage, unpaid ' +
       'rent and charges. It is refunded after the room has been inspected at vacate, less any amounts properly owing, ' +
       'and after the tenant has been given a written account of any deductions.'],

      ['Administration fee',
       'The administration fee of ' + rands(l.admin_fee) + ' is payable to reserve the room. It is not refundable and ' +
       'is not rent.'],

      ['House rules',
       'The Ligcabho house rules form part of this agreement and are binding on the tenant. They cover water and ' +
       'electricity use, consideration of others, care of the building and rooms, smoking, drugs and alcohol, medical ' +
       'conditions, security, visitors, pregnancy, parking and compliance. A copy is issued with this lease and is ' +
       'published on the website.'],

      ['Visitors',
       'Visitors sign in at the front desk. A scheduled sleepover is charged at R135 per person with proof of payment; ' +
       'an unscheduled visitor is charged at R200 per visitor to the tenant\'s rental account. No visitor may occupy ' +
       'the room in the tenant\'s absence.'],

      ['Maintenance and inspections',
       'The tenant reports all maintenance in the book at the front desk. The landlord maintains the building and ' +
       'attends to logged items within the published turnaround times. Rooms are inspected twice a month; damage found ' +
       'on inspection is charged to the tenant\'s account and repaired once paid. The tenant completes the room ' +
       'occupation inspection list within 48 hours of receiving this lease.'],

      ['Services and interruptions',
       'Water, electricity, Wi-Fi and security services are provided as described for the residence. The landlord is ' +
       'not liable for interruptions outside its control, including municipal outages and load shedding, but will ' +
       'restore services as soon as reasonably possible.'],

      ['Vacating',
       'The tenant collects a vacate note from the office 24 hours before vacating. A note is only issued when the ' +
       'account is paid in full. At year end the room is inspected, damages are charged, and any refund is paid after ' +
       'deductions.'],

      ['Breach and cancellation',
       'If the tenant breaches this agreement and does not remedy the breach within seven days of written notice, the ' +
       'landlord may cancel the lease, reclaim the room and recover any loss. Serious breaches of the security, drug ' +
       'or conduct rules may lead to immediate cancellation, and the tenant\'s funder may be informed.'],

      ['Liability',
       'The tenant occupies the room and uses the common areas at their own risk. The landlord is not liable for loss ' +
       'of or damage to the tenant\'s property except where the loss is caused by the landlord\'s own gross ' +
       'negligence. Tenants are encouraged to insure their belongings.'],

      ['Personal information',
       'The landlord processes the tenant\'s personal information to administer this lease, in line with POPIA. ' +
       'Information is shared with the tenant\'s funder or institution only where that is needed to confirm placement ' +
       'or payment.'],

      ['Whole agreement',
       'This agreement, together with the house rules, is the whole agreement between the parties. Any variation must ' +
       'be in writing and signed by both. Domicile addresses are the landlord\'s address at ' +
       esc(t.landlord_address || '') + ' and the tenant\'s home address given below.']
    ];

    return items.map(function (c, i) {
      return '<h3>' + (i + 1) + '. ' + c[0] + '</h3><p>' + c[1] + '</p>';
    }).join('');
  }

  /* ------------------------------- rendering ----------------------------- */
  function render() {
    var full = lease.tenant_name + ' ' + lease.tenant_surname;

    $('#head-parties').textContent =
      (terms.landlord_entity || 'The landlord') + ' and ' + full + ' · ' +
      (lease.residence || '') + (lease.room_number ? ', room ' + lease.room_number : '');

    $('#parties').innerHTML = dl([
      ['Landlord', terms.landlord_entity],
      ['Landlord address', terms.landlord_address],
      ['Landlord email', terms.landlord_email],
      ['Tenant', full],
      ['Tenant ID number', lease.tenant_id_number],
      ['Tenant phone', lease.tenant_phone],
      ['Tenant email', lease.tenant_email],
      ['Student number', lease.student_number],
      ['Institution', lease.institution],
      ['Course', lease.course],
      ['Year of study', lease.year_of_study]
    ]);

    $('#terms').innerHTML = dl([
      ['Residence', lease.residence],
      ['Room number', lease.room_number],
      ['Room type', lease.room_type],
      ['Occupation from', lease.commencement_date],
      ['Until', lease.end_date],
      ['Monthly rent', lease.monthly_rent ? rands(lease.monthly_rent) : ''],
      ['Deposit', lease.deposit ? rands(lease.deposit) : ''],
      ['Administration fee', lease.admin_fee ? rands(lease.admin_fee) : ''],
      ['Funder', lease.funder]
    ]);

    $('#clauses').innerHTML = '<h2>Terms and conditions</h2>' + clauses(lease, terms);

    if (lease.special_conditions) {
      $('#special').textContent = lease.special_conditions;
      $('#special-wrap').hidden = false;
    }

    renderSignatures();

    var signed = lease.status === 'signed' || lease.status === 'countersigned';
    $('#sign-form').hidden = signed;
    $('#done-actions').hidden = !signed;

    var banner = $('#banner');
    if (lease.status === 'countersigned') {
      banner.className = 'lease-banner lease-banner--done';
      banner.textContent = 'Signed by both parties on ' + fmtDate(lease.landlord_signed_at) + '. Keep a copy for your records.';
    } else if (signed) {
      banner.className = 'lease-banner lease-banner--done';
      banner.textContent = 'You signed this lease on ' + fmtDate(lease.tenant_signed_at) +
        '. Ligcabho will counter-sign and your copy will update here.';
    } else {
      banner.className = 'lease-banner';
      banner.textContent = 'Please read the whole agreement, then sign at the bottom of the page.';
    }

    $('#name-hint').textContent = 'Type it exactly as: ' + full;
    $('#state').hidden = true;
    $('#doc').hidden = false;
  }

  function renderSignatures() {
    var full = lease.tenant_name + ' ' + lease.tenant_surname;
    var tenant = lease.tenant_signature
      ? '<img class="sig__img" src="' + lease.tenant_signature + '" alt="Tenant signature">' +
        '<p class="sig__meta">' + esc(lease.tenant_signed_name || full) + '<br>Signed ' + esc(fmtDate(lease.tenant_signed_at)) + '</p>'
      : '<p class="sig__meta">Not yet signed</p>';

    var landlord = lease.landlord_signature
      ? '<img class="sig__img" src="' + lease.landlord_signature + '" alt="Landlord signature">' +
        '<p class="sig__meta">' + esc(lease.landlord_signed_name || terms.landlord_entity) +
        '<br>Signed ' + esc(fmtDate(lease.landlord_signed_at)) + '</p>'
      : '<p class="sig__meta">Awaiting counter-signature</p>';

    $('#signatures').innerHTML =
      '<h2>Signatures</h2><div class="sig-grid">' +
        '<div class="sig-box"><span class="sig-box__label">Tenant</span>' + tenant + '</div>' +
        '<div class="sig-box"><span class="sig-box__label">For ' + esc(terms.landlord_entity || 'the landlord') +
        '</span>' + landlord + '</div>' +
      '</div>';
  }

  /* ---------------------------- signature pad ---------------------------- */
  var pad = $('#pad');
  var ctx = null;
  var drew = false;

  function sizePad() {
    if (!pad) return;
    var ratio = window.devicePixelRatio || 1;
    var w = pad.parentNode.clientWidth;
    var h = 170;
    pad.width = w * ratio;
    pad.height = h * ratio;
    pad.style.width = w + 'px';
    pad.style.height = h + 'px';
    ctx = pad.getContext('2d');
    ctx.scale(ratio, ratio);
    ctx.lineWidth = 2.2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#1b1410';
  }

  function point(e) {
    var r = pad.getBoundingClientRect();
    var t = e.touches ? e.touches[0] : e;
    return { x: t.clientX - r.left, y: t.clientY - r.top };
  }

  function bindPad() {
    if (!pad) return;
    var drawing = false;

    var down = function (e) {
      e.preventDefault();
      drawing = true;
      drew = true;
      $('#pad-hint').hidden = true;
      var p = point(e);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
    };
    var move = function (e) {
      if (!drawing) return;
      e.preventDefault();
      var p = point(e);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
    };
    var up = function () { drawing = false; };

    pad.addEventListener('mousedown', down);
    pad.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    pad.addEventListener('touchstart', down, { passive: false });
    pad.addEventListener('touchmove', move, { passive: false });
    pad.addEventListener('touchend', up);

    $('#sig-clear').addEventListener('click', function () {
      if (ctx) ctx.clearRect(0, 0, pad.width, pad.height);
      drew = false;
      $('#pad-hint').hidden = false;
      $('#typed').value = '';
      $('#typed-preview').textContent = '';
    });

    Array.prototype.forEach.call(document.querySelectorAll('.sig__tab'), function (tab) {
      tab.addEventListener('click', function () {
        sigMode = tab.dataset.mode;
        Array.prototype.forEach.call(document.querySelectorAll('.sig__tab'), function (t) {
          var on = t === tab;
          t.classList.toggle('is-on', on);
          t.setAttribute('aria-selected', String(on));
        });
        $('#pad-wrap').hidden = sigMode !== 'draw';
        $('#typed-wrap').hidden = sigMode !== 'type';
        if (sigMode === 'draw') sizePad();
      });
    });

    $('#typed').addEventListener('input', function () {
      $('#typed-preview').textContent = $('#typed').value;
    });

    window.addEventListener('resize', function () { if (sigMode === 'draw' && !drew) sizePad(); });
  }

  /** Flatten whichever signature the tenant gave into a PNG data URL. */
  function signatureData() {
    if (sigMode === 'type') {
      var text = $('#typed').value.trim();
      if (text.length < 3) return null;
      var c = document.createElement('canvas');
      c.width = 760;
      c.height = 200;
      var g = c.getContext('2d');
      g.fillStyle = '#fff';
      g.fillRect(0, 0, c.width, c.height);
      g.fillStyle = '#1b1410';
      g.font = 'italic 64px "Segoe Script", "Brush Script MT", cursive';
      g.textBaseline = 'middle';
      g.fillText(text, 30, 110);
      return c.toDataURL('image/png');
    }
    if (!drew) return null;
    var out = document.createElement('canvas');
    out.width = pad.width;
    out.height = pad.height;
    var o = out.getContext('2d');
    o.fillStyle = '#fff';
    o.fillRect(0, 0, out.width, out.height);
    o.drawImage(pad, 0, 0);
    return out.toDataURL('image/png');
  }

  /* -------------------------------- signing ------------------------------ */
  function fieldError(id, message) {
    var field = $(id).closest('.field');
    var box = field ? field.querySelector('.field__error') : null;
    if (field) field.classList.toggle('field--error', !!message);
    if (box) {
      box.textContent = message || '';
      box.hidden = !message;
    }
    return !message;
  }

  function submit(e) {
    e.preventDefault();
    var status = $('#sign-status');
    status.hidden = true;

    var ok = true;
    ok = fieldError('#home-address', $('#home-address').value.trim() ? '' : 'Please give your permanent home address.') && ok;
    ok = fieldError('#kin-name', $('#kin-name').value.trim() ? '' : 'Please give a next of kin.') && ok;
    ok = fieldError('#kin-contact', $('#kin-contact').value.trim() ? '' : 'Please give their contact number.') && ok;

    var full = (lease.tenant_name + ' ' + lease.tenant_surname).toLowerCase().trim();
    var typed = $('#signed-name').value.toLowerCase().trim();
    ok = fieldError('#signed-name', typed === full ? '' :
      'Type your name exactly as: ' + lease.tenant_name + ' ' + lease.tenant_surname) && ok;

    var sig = signatureData();
    $('#sig-err').hidden = !!sig;
    $('#sig-err').textContent = sig ? '' : 'Please draw or type your signature.';
    if (!sig) ok = false;

    var agreed = $('#agree').checked;
    $('#agree-err').hidden = agreed;
    $('#agree-err').textContent = agreed ? '' : 'Please tick the box to accept the agreement.';
    if (!agreed) ok = false;

    if (!ok) return;

    var btn = $('#sign-btn');
    btn.disabled = true;
    btn.textContent = 'Signing…';

    fetch(API + 'lease/' + encodeURIComponent(token) + '/sign', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        signed_name: $('#signed-name').value.trim(),
        home_address: $('#home-address').value.trim(),
        kin_name: $('#kin-name').value.trim(),
        kin_contact: $('#kin-contact').value.trim(),
        signature: sig,
        agree: 1
      })
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok || j.ok === false) throw new Error(j.error || 'That did not go through. Please try again.');
        return j;
      });
    }).then(function () {
      lease.status = 'signed';
      lease.tenant_signature = sig;
      lease.tenant_signed_name = $('#signed-name').value.trim();
      lease.tenant_signed_at = new Date().toISOString();
      render();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }).catch(function (err) {
      status.textContent = err.message;
      status.className = 'form__status form__status--err';
      status.hidden = false;
      btn.disabled = false;
      btn.textContent = 'Sign the lease';
    });
  }

  /* --------------------------------- boot -------------------------------- */
  if (!token) {
    problem('That link is missing its lease reference. Please use the link Ligcabho emailed you.');
    return;
  }

  fetch(API + 'lease/' + encodeURIComponent(token), { headers: { Accept: 'application/json' } })
    .then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok || j.ok === false) throw new Error(j.error || 'That lease link is not valid.');
        return j;
      });
    })
    .then(function (d) {
      lease = d.lease;
      terms = d.terms || {};
      render();
      sizePad();
      bindPad();
      $('#sign-form').addEventListener('submit', submit);
      $('#print-btn').addEventListener('click', function () { window.print(); });
      $('#print-btn-2').addEventListener('click', function () { window.print(); });
      var pdf = API + 'lease/' + encodeURIComponent(token) + '/pdf';
      $('#pdf-btn').href = pdf;
      $('#pdf-btn-2').href = pdf;
    })
    .catch(function (err) { problem(err.message); });
})();
