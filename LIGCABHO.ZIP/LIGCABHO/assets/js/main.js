/**
 * Ligcabho Le'Africa Residences — site behaviour.
 * No framework, no build step. Progressive enhancement only:
 * every page reads and every form submits without this file.
 */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  // Pages sit at the site root, so the API is always one hop down from here.
  var API = window.LIGCABHO_API_BASE || 'api/';

  function post(path, body) {
    var opts = { method: 'POST', credentials: 'same-origin' };
    if (body instanceof FormData) {
      opts.body = body;
    } else {
      opts.headers = { 'Content-Type': 'application/json' };
      opts.body = JSON.stringify(body);
    }
    return fetch(API + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok || j.ok === false) throw new Error(j.error || 'Something went wrong. Please try again.');
        return j;
      });
    });
  }

  /* ------------------------------ mobile nav ----------------------------- */
  var toggle = $('.nav-toggle');
  var nav = $('#primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      toggle.setAttribute('aria-label', open ? 'Open menu' : 'Close menu');
      nav.classList.toggle('is-open', !open);
    });
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a') && window.matchMedia('(max-width: 1080px)').matches) {
        toggle.setAttribute('aria-expanded', 'false');
        nav.classList.remove('is-open');
      }
    });
  }

  /* ---------------------------- residence filters ------------------------ */
  var filterForm = $('#res-filters');
  if (filterForm) {
    var cards = $$('[data-residence]');
    var count = $('#res-count');

    var applyFilters = function () {
      var inst = $('#f-institution').value;
      var area = $('#f-area').value;
      var room = $('#f-room').value;
      var q = ($('#f-search').value || '').trim().toLowerCase();
      var shown = 0;

      cards.forEach(function (card) {
        var ok = true;
        if (inst && (card.dataset.institutions || '').indexOf(inst) === -1) ok = false;
        if (area && card.dataset.area !== area) ok = false;
        if (room && (card.dataset.rooms || '').indexOf(room) === -1) ok = false;
        if (q && (card.dataset.search || '').indexOf(q) === -1) ok = false;
        card.hidden = !ok;
        if (ok) shown++;
      });

      if (count) count.textContent = shown + (shown === 1 ? ' residence' : ' residences');
      var empty = $('#res-empty');
      if (empty) empty.hidden = shown !== 0;
    };

    filterForm.addEventListener('input', applyFilters);
    filterForm.addEventListener('change', applyFilters);
    filterForm.addEventListener('submit', function (e) { e.preventDefault(); applyFilters(); });
    var reset = $('#f-reset');
    if (reset) reset.addEventListener('click', function () { filterForm.reset(); applyFilters(); });
    applyFilters();
  }

  /* -------------------------------- lightbox ----------------------------- */
  var gallery = $('[data-gallery]');
  if (gallery) {
    var thumbs = $$('button', gallery);
    var shots = thumbs.map(function (b) {
      var img = $('img', b);
      return { src: b.dataset.full || img.src, alt: img.alt };
    });

    var box = document.createElement('div');
    box.className = 'lightbox';
    box.hidden = true;
    box.innerHTML =
      '<button class="lightbox__close" type="button" aria-label="Close">&times;</button>' +
      '<button class="lightbox__nav lightbox__nav--prev" type="button" aria-label="Previous photo">&#8249;</button>' +
      '<img alt="">' +
      '<button class="lightbox__nav lightbox__nav--next" type="button" aria-label="Next photo">&#8250;</button>' +
      '<p class="lightbox__caption"></p>';
    document.body.appendChild(box);

    var boxImg = $('img', box);
    var caption = $('.lightbox__caption', box);
    var at = 0;
    var opener = null;

    var show = function (i) {
      at = (i + shots.length) % shots.length;
      boxImg.src = shots[at].src;
      boxImg.alt = shots[at].alt;
      caption.textContent = (at + 1) + ' / ' + shots.length + ' · ' + shots[at].alt;
    };
    var openBox = function (i, btn) {
      opener = btn;
      show(i);
      box.hidden = false;
      document.body.style.overflow = 'hidden';
      $('.lightbox__close', box).focus();
    };
    var closeBox = function () {
      box.hidden = true;
      document.body.style.overflow = '';
      if (opener) opener.focus();
    };

    thumbs.forEach(function (b, i) {
      b.addEventListener('click', function () { openBox(i, b); });
    });
    box.addEventListener('click', function (e) {
      if (e.target === box || e.target.closest('.lightbox__close')) closeBox();
      else if (e.target.closest('.lightbox__nav--prev')) show(at - 1);
      else if (e.target.closest('.lightbox__nav--next')) show(at + 1);
    });
    document.addEventListener('keydown', function (e) {
      if (box.hidden) return;
      if (e.key === 'Escape') closeBox();
      if (e.key === 'ArrowLeft') show(at - 1);
      if (e.key === 'ArrowRight') show(at + 1);
    });
  }

  /* --------------------------------- forms ------------------------------- */
  function setStatus(form, message, kind) {
    var box = $('[data-status]', form);
    if (!box) return;
    box.textContent = message;
    box.className = 'form__status form__status--' + kind;
    box.hidden = false;
    box.setAttribute('role', kind === 'err' ? 'alert' : 'status');
  }

  function busy(form, on, label) {
    var btn = $('[type="submit"]', form);
    if (!btn) return;
    if (on) {
      btn.dataset.label = btn.textContent;
      btn.disabled = true;
      btn.textContent = label || 'Sending…';
    } else {
      btn.disabled = false;
      btn.textContent = btn.dataset.label || 'Submit';
    }
  }

  // Any form with data-endpoint posts to the API and reports back in place.
  $$('form[data-endpoint]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.reportValidity()) return;

      var hasFile = !!$('input[type="file"]', form);
      var payload;

      if (hasFile) {
        payload = new FormData(form);
      } else {
        payload = {};
        new FormData(form).forEach(function (v, k) {
          if (payload[k] === undefined) payload[k] = v;
          else payload[k] = [].concat(payload[k], v).join(', ');
        });
      }

      busy(form, true, form.dataset.busy || 'Sending…');
      post(form.dataset.endpoint, payload)
        .then(function (res) {
          form.reset();
          var msg = res.message || form.dataset.success || 'Thank you — we have received it.';
          if (form.dataset.reference !== undefined && res.reference) {
            msg += ' Your reference is ' + res.reference + '.';
          }
          setStatus(form, msg, 'ok');
        })
        .catch(function (err) { setStatus(form, err.message, 'err'); })
        .then(function () { busy(form, false); });
    });
  });

  /* --------------------------- year in the footer ------------------------ */
  $$('[data-year]').forEach(function (el) { el.textContent = String(new Date().getFullYear()); });
})();
