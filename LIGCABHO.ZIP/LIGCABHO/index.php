<?php
/**
 * Front door.
 *
 * This file exists to take over from WordPress.
 *
 * The site is plain static HTML and does not need PHP to serve its pages. But
 * a cPanel host almost always lists index.php before index.html in its
 * DirectoryIndex, so as long as WordPress's own index.php is still sitting in
 * public_html, the server keeps booting WordPress and the old site keeps
 * rendering, however many times the new files are uploaded.
 *
 * Uploading this file overwrites WordPress's index.php, because the name is the
 * same. From that moment the correct homepage is served whichever order the
 * host prefers, and whatever a leftover WordPress .htaccess says.
 *
 * WordPress's rewrite rules send every unmatched request here, so this also
 * resolves those to the right static page rather than the homepage.
 */
declare(strict_types=1);

$root = __DIR__;
$path = parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';
$path = rawurldecode($path);

/* Strip a subdirectory prefix, for installs that are not at the domain root. */
$base = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
if ($base !== '' && str_starts_with($path, $base)) {
    $path = substr($path, strlen($base));
}
$path = trim($path, '/');

/* The homepage. */
if ($path === '' || $path === 'index.php') {
    readfile($root . '/index.html');
    exit;
}

$key = strtolower(rtrim($path, '/'));

/* The addresses the old WordPress site used, pointed at their new pages. */
$moved = [
    'home'                            => 'index.html',
    'about-us'                        => 'about-us.html',
    'accreditations'                  => 'accreditations.html',
    'urban-regeneration'              => 'urban-regeneration.html',
    'student-zone'                    => 'student-zone.html',
    'ligcabhore-lvl-up'               => 'lvl-up.html',
    'student-safety'                  => 'student-safety.html',
    'emergency'                       => 'emergency.html',
    'faqs'                            => 'faqs.html',
    'house-rules'                     => 'house-rules.html',
    'contact-us'                      => 'get-in-touch.html',
    'jobs-search'                     => 'careers.html',
    'application-form'                => 'apply.html',
    'our-locations'                   => 'residences.html',
    /* The residence pages. */
    '8-jan-frederik'                  => 'residence-8-jan-frederik.html',
    '10-jan-frederik'                 => 'residence-10-jan-frederik.html',
    '14-jan-frederik'                 => 'residence-14-jan-frederik.html',
    'boslorie'                        => 'residence-53-boslorie.html',
    '53-boslorie'                     => 'residence-53-boslorie.html',
    'silver-oak'                      => 'residence-1-silver-oak.html',
    '16-sperwer-street'               => 'residence-16-sperwer-street.html',
    '2022-drysdale'                   => 'residence-20-22-drysdale.html',
    '21-van-rooyen-stonehenge'        => 'residence-21-van-rooyen.html',
    '23-dolomiet'                     => 'residence-23-dolomiet.html',
    'mataffin'                        => 'residence-48-mataffin-hill.html',
    '49-mostert-3'                    => 'residence-49-mostert.html',
    '72-percy-fitzpatrick'            => 'residence-72-percy-fitzpatrick.html',
    '74-percy-views'                  => 'residence-74a-percy-fitzpatrick.html',
    '9-sarel-street'                  => 'residence-9-sarel-cilliers.html',
    '01-penny-street'                 => 'residence-01-penny-street.html',
    'plot-no-80-burger-street'        => 'residence-plot-80-burger-street.html',
    'portion-10-farm-rockys-drift'    => 'residence-portion-10-rockys-drift.html',
];

if (isset($moved[$key]) && is_file($root . '/' . $moved[$key])) {
    header('Location: /' . $moved[$key], true, 301);
    exit;
}

/* A clean URL for a page that exists: /residences -> residences.html */
$candidate = $root . '/' . $key . '.html';
if ($key !== '' && strpos($key, '..') === false && is_file($candidate)) {
    readfile($candidate);
    exit;
}

/* Anything else. */
http_response_code(404);
readfile($root . '/404.html');
