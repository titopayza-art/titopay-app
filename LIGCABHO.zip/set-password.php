<?php
/**
 * Reset the admin password.
 *
 * Changing api/config.php only affects a brand new installation, because the
 * administrator is created once on first run and the password is stored as a
 * hash from then on. This resets the password on an installation that is
 * already live.
 *
 * Upload it, open https://ligcabhoresidences.co.za/set-password.php, set the
 * password, and it removes itself. If it cannot remove itself it says so, and
 * you must delete it by hand: while it sits there, anyone who finds it can
 * take over the portal.
 */
declare(strict_types=1);
require __DIR__ . '/api/bootstrap.php';

$done = false; $error = ''; $selfDeleted = false; $newPw = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $email = strtolower(trim((string)($_POST['email'] ?? 'admin@ligcabhoresidences.co.za')));
    $newPw = (string)($_POST['password'] ?? '');
    $again = (string)($_POST['confirm'] ?? '');

    if ($newPw === '')                 $error = 'Type the password you want.';
    elseif (strlen($newPw) < 10)       $error = 'Use at least 10 characters.';
    elseif ($newPw !== $again)         $error = 'The two passwords do not match.';
    elseif ($newPw === cfg('staff.temporary_password'))
                                       $error = 'That is the shared temporary password. Choose something else.';
    else {
        try {
            $st = db()->prepare('SELECT id FROM users WHERE email = ?');
            $st->execute([$email]);
            $row = $st->fetch();

            if ($row) {
                db()->prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')
                    ->execute([password_hash($newPw, PASSWORD_DEFAULT), $row['id']]);
            } else {
                db()->prepare('INSERT INTO users (email,name,password_hash,role,active,must_change_password,created_at)
                               VALUES (?,?,?,?,1,0,?)')
                    ->execute([$email, 'Administrator',
                               password_hash($newPw, PASSWORD_DEFAULT), 'owner', now()]);
            }

            /* Clear any lockout from failed attempts, so you can sign in at once. */
            db()->exec('DELETE FROM login_attempts');

            $done = true;
            $selfDeleted = @unlink(__FILE__);
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow');
?><!doctype html>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reset the Ligcabho admin password</title>
<style>
 body{margin:0;background:#f7f4ef;color:#221c18;font:16px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
 .wrap{max-width:560px;margin:0 auto;padding:32px 18px 70px}
 h1{font-size:1.4rem;margin:0 0 .2rem}.sub{color:#7b6f67;margin:0 0 20px}
 .box{background:#fff;border-radius:14px;padding:18px 20px;margin:16px 0;
   box-shadow:0 1px 3px rgba(34,28,24,.1);border-left:4px solid #f5951d}
 .ok{border-left-color:#0f8a52}.bad{border-left-color:#c0392b}.warn{border-left-color:#b4690e}
 label{display:block;font-weight:600;font-size:.9rem;margin:.9rem 0 .3rem}
 input{width:100%;box-sizing:border-box;padding:.8rem .9rem;font:inherit;
   border:1.5px solid #e7e0d7;border-radius:10px;background:#fff;color:#221c18}
 input:focus{outline:none;border-color:#f5951d;box-shadow:0 0 0 4px rgba(245,149,29,.2)}
 button{margin-top:1.1rem;font:inherit;font-weight:700;color:#1b1410;background:#f5951d;
   border:0;border-radius:999px;padding:.85rem 1.6rem;cursor:pointer}
 button:hover{background:#d97a08}
 code{background:#f7f4ef;padding:.1rem .35rem;border-radius:4px}
 .big{font-size:1.05rem;font-weight:700}
</style>
<div class="wrap">
<h1>Reset the admin password</h1>
<p class="sub">Ligcabho admin portal</p>

<?php if ($done): ?>
  <div class="box ok">
    <span class="big">Password changed.</span>
    <p>Sign in at <a href="admin/">/admin/</a> with
       <code><?= htmlspecialchars(strtolower(trim((string)($_POST['email'] ?? 'admin@ligcabhoresidences.co.za')))) ?></code>
       and the password you just set. You will not be asked to change it again.</p>
  </div>
  <?php if ($selfDeleted): ?>
    <div class="box ok">This file has deleted itself. Nothing further to do.</div>
  <?php else: ?>
    <div class="box bad"><span class="big">Delete this file now.</span>
      <p>It could not remove itself, probably a permissions setting. Delete
      <code>set-password.php</code> in cPanel File Manager. While it is there,
      anyone who finds the address can reset your password.</p></div>
  <?php endif; ?>

<?php else: ?>
  <?php if ($error): ?><div class="box bad"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <div class="box warn">
    <p>This changes the password of one staff account on the live site — by default the
    administrator, but any of the five addresses can be typed in. The file removes itself as
    soon as it has worked.</p>
  </div>
  <form method="post" autocomplete="off">
    <div class="box">
      <label for="e">Administrator email</label>
      <input id="e" name="email" type="email" value="<?= htmlspecialchars((string)'admin@ligcabhoresidences.co.za') ?>" required>
      <label for="p">New password</label>
      <input id="p" name="password" type="text" placeholder="At least 10 characters" required>
      <label for="c">Type it again</label>
      <input id="c" name="confirm" type="text" required>
      <button type="submit">Set this password</button>
    </div>
  </form>
<?php endif; ?>
</div>
