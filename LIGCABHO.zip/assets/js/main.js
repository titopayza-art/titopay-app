/**
 * Ligcabho Le'Africa Residences — site behaviour.
 * No framework, no build step. Progressive enhancement only:
 * every page reads and every form submits without this file.
 */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  // Pages sit at the site root, so the API is always one hop down from here.
  var API = window.LIGCABHO_API_BASE || 'api/';

  function post(path, body) {
    var opts = { method: 'POST', credentials: 'same-origin' };
    if (body instanceof FormData) {
      opts.body = body;
    } else {
      opts.headers = { 'Content-Type': 'application/json' };
      opts.body = JSON.stringify(body);
    }
    return fetch(API + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok || j.ok === false) throw new Error(j.error || 'Something went wrong. Please try again.');
        return j;
      });
    });
  }

  /* ------------------------------ mobile nav ----------------------------- */
  var toggle = $('.nav-toggle');
  var nav = $('#primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      toggle.setAttribute('aria-label', open ? 'Open menu' : 'Close menu');
      nav.classList.toggle('is-open', !open);
    });
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a') && window.matchMedia('(max-width: 1080px)').matches) {
        toggle.setAttribute('aria-expanded', 'false');
        nav.classList.remove('is-open');
      }
    });
  }

  /* --------------------- arriving from a residence page ------------------ */
  /* "Apply for this residence" carries the house with it, so the form opens
     with that one already chosen and says so. */
  (function () {
    var sel = document.querySelector('select[name="residence"]');
    if (!sel) return;
    var want = (location.search.match(/[?&]residence=([^&]+)/) || [])[1];
    if (!want) return;
    want = decodeURIComponent(want);
    var list = window.LIGCABHO_RESIDENCES || [];
    var match = list.filter(function (r) { return r.slug === want || r.name === want; })[0];
    var name = match ? match.name : want;
    for (var i = 0; i < sel.options.length; i++) {
      if (sel.options[i].value === name || sel.options[i].text === name) {
        sel.selectedIndex = i;
        var note = document.createElement('p');
        note.className = 'form__picked';
        note.innerHTML = 'Applying for <strong>' + name.replace(/[<>&]/g, '') + '</strong>. ' +
          'Change it above if you would rather be placed somewhere else.';
        sel.parentNode.appendChild(note);
        break;
      }
    }
  })();

  /* ---------------------------- residence filters ------------------------ */
  var filterForm = $('#res-filters');
  if (filterForm) {
    var cards = $$('[data-residence]');
    var count = $('#res-count');

    var applyFilters = function () {
      var inst = $('#f-institution').value;
      var area = $('#f-area').value;
      var room = $('#f-room').value;
      var q = ($('#f-search').value || '').trim().toLowerCase();
      var shown = 0;

      cards.forEach(function (card) {
        var ok = true;
        if (inst && (card.dataset.institutions || '').indexOf(inst) === -1) ok = false;
        if (area && card.dataset.area !== area) ok = false;
        if (room && (card.dataset.rooms || '').indexOf(room) === -1) ok = false;
        if (q && (card.dataset.search || '').indexOf(q) === -1) ok = false;
        card.hidden = !ok;
        if (ok) shown++;
      });

      var on = Boolean(inst || area || room || q);
      if (count) {
        count.textContent = on
          ? shown + (shown === 1 ? ' residence matches' : ' residences match')
          : shown + ' residences';
      }
      var clear = $('#f-reset');
      if (clear) clear.hidden = !on;
      var empty = $('#res-empty');
      if (empty) empty.hidden = shown !== 0;
    };

    /* The institution filter is a row of chips rather than a dropdown: on a
       phone it is one tap instead of three, and it shows how many houses
       each institution has without opening anything. */
    var pills = $$('.pill', filterForm);
    pills.forEach(function (b) {
      b.addEventListener('click', function () {
        pills.forEach(function (o) { o.classList.toggle('is-on', o === b); });
        $('#f-institution').value = b.dataset.inst || '';
        applyFilters();
      });
    });

    filterForm.addEventListener('input', applyFilters);
    filterForm.addEventListener('change', applyFilters);
    filterForm.addEventListener('submit', function (e) { e.preventDefault(); applyFilters(); });

    var reset = $('#f-reset');
    if (reset) {
      reset.addEventListener('click', function () {
        $('#f-area').value = '';
        $('#f-room').value = '';
        $('#f-search').value = '';
        $('#f-institution').value = '';
        pills.forEach(function (o) { o.classList.toggle('is-on', !o.dataset.inst); });
        applyFilters();
      });
    }
    applyFilters();
  }

  /* -------------------------------- lightbox ----------------------------- */
  var gallery = $('[data-gallery]');
  if (gallery) {
    var thumbs = $$('button', gallery);
    var shots = thumbs.map(function (b) {
      var img = $('img', b);
      return { src: b.dataset.full || img.src, alt: img.alt };
    });

    var box = document.createElement('div');
    box.className = 'lightbox';
    box.hidden = true;
    box.innerHTML =
      '<button class="lightbox__close" type="button" aria-label="Close">&times;</button>' +
      '<button class="lightbox__nav lightbox__nav--prev" type="button" aria-label="Previous photo">&#8249;</button>' +
      /* a transparent pixel until a photo is chosen, so the empty frame is
         never a broken image */
      '<img alt="" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7">' +
      '<button class="lightbox__nav lightbox__nav--next" type="button" aria-label="Next photo">&#8250;</button>' +
      '<p class="lightbox__caption"></p>';
    document.body.appendChild(box);

    var boxImg = $('img', box);
    var caption = $('.lightbox__caption', box);
    var at = 0;
    var opener = null;

    var show = function (i) {
      at = (i + shots.length) % shots.length;
      boxImg.src = shots[at].src;
      boxImg.alt = shots[at].alt;
      caption.textContent = (at + 1) + ' / ' + shots.length + ' · ' + shots[at].alt;
    };
    var openBox = function (i, btn) {
      opener = btn;
      show(i);
      box.hidden = false;
      document.body.style.overflow = 'hidden';
      $('.lightbox__close', box).focus();
    };
    var closeBox = function () {
      box.hidden = true;
      document.body.style.overflow = '';
      if (opener) opener.focus();
    };

    thumbs.forEach(function (b, i) {
      b.addEventListener('click', function () { openBox(i, b); });
    });
    box.addEventListener('click', function (e) {
      if (e.target === box || e.target.closest('.lightbox__close')) closeBox();
      else if (e.target.closest('.lightbox__nav--prev')) show(at - 1);
      else if (e.target.closest('.lightbox__nav--next')) show(at + 1);
    });
    document.addEventListener('keydown', function (e) {
      if (box.hidden) return;
      if (e.key === 'Escape') closeBox();
      if (e.key === 'ArrowLeft') show(at - 1);
      if (e.key === 'ArrowRight') show(at + 1);
    });
  }


  /** A South African ID number: 13 digits with the Luhn check digit. */
  function validSaId(v) {
    var id = String(v || '').replace(/\D/g, '');
    if (!/^\d{13}$/.test(id)) return false;
    var sum = 0;
    for (var i = 0; i < 13; i++) {
      var d = Number(id[i]);
      if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
      sum += d;
    }
    return sum % 10 === 0;
  }

  /* --------------------------------- forms ------------------------------- */
  function setStatus(form, message, kind) {
    var box = $('[data-status]', form);
    if (!box) return;
    box.textContent = message;
    box.className = 'form__status form__status--' + kind;
    box.hidden = false;
    box.setAttribute('role', kind === 'err' ? 'alert' : 'status');
  }

  function busy(form, on, label) {
    var btn = $('[type="submit"]', form);
    if (!btn) return;
    if (on) {
      btn.dataset.label = btn.textContent;
      btn.disabled = true;
      btn.textContent = label || 'Sending…';
    } else {
      btn.disabled = false;
      btn.textContent = btn.dataset.label || 'Submit';
    }
  }

  // ID numbers are checked here too, so the student is told at the field and
  // not after filling in the whole form.
  $$('input[name="id_number"]').forEach(function (input) {
    var verdict = function () {
      var v = input.value.trim();
      input.setCustomValidity(v === '' || validSaId(v)
        ? '' : 'That ID number does not check out — please read it off your ID.');
    };
    input.addEventListener('input', verdict);
    input.addEventListener('blur', verdict);
  });

  // Any form with data-endpoint posts to the API and reports back in place.
  $$('form[data-endpoint]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.reportValidity()) return;

      var hasFile = !!$('input[type="file"]', form);
      var payload;

      if (hasFile) {
        payload = new FormData(form);
      } else {
        payload = {};
        new FormData(form).forEach(function (v, k) {
          if (payload[k] === undefined) payload[k] = v;
          else payload[k] = [].concat(payload[k], v).join(', ');
        });
      }

      busy(form, true, form.dataset.busy || 'Sending…');
      post(form.dataset.endpoint, payload)
        .then(function (res) {
          form.reset();
          var msg = res.message || form.dataset.success || 'Thank you — we have received it.';
          // The API usually names the reference itself; only add it if it did not.
          if (form.dataset.reference !== undefined && res.ref && msg.indexOf(res.ref) === -1) {
            msg += ' Your reference is ' + res.ref + '.';
          }
          setStatus(form, msg, 'ok');
        })
        .catch(function (err) { setStatus(form, err.message, 'err'); })
        .then(function () { busy(form, false); });
    });
  });


  /* --------------------- published reviews on the site ------------------- */
  var reviewList = $('#review-list');
  if (reviewList) {
    var starRow = function (n) {
      var out = '';
      for (var i = 1; i <= 5; i++) out += i <= Number(n) ? '★' : '☆';
      return out;
    };
    fetch(API + 'reviews/published', { headers: { Accept: 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.ok || !d.items || !d.items.length) return;
        /* On the home page the whole strip is hidden until there is
           something real to put in it. */
        var strip = document.getElementById('home-reviews');
        var items = strip ? d.items.slice(0, 3) : d.items;
        if (strip) strip.hidden = false;
        reviewList.innerHTML = items.map(function (r) {
          var when = new Date(r.created_at);
          var date = isNaN(when.getTime()) ? '' : when.toLocaleDateString('en-ZA', { month: 'long', year: 'numeric' });
          var esc = function (t) {
            return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) {
              return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
            });
          };
          return '<article class="card review">' +
            '<p class="review__stars" aria-label="' + esc(r.rating) + ' out of 5">' + starRow(r.rating) + '</p>' +
            (r.title ? '<h3>' + esc(r.title) + '</h3>' : '') +
            '<p>' + esc(r.body) + '</p>' +
            (r.reply ? '<p class="review__reply"><strong>Ligcabho replied:</strong> ' + esc(r.reply) + '</p>' : '') +
            '<p class="review__by">' + esc(r.name) + ' &middot; ' + esc(r.residence) +
            (date ? ' &middot; ' + esc(date) : '') + '</p></article>';
        }).join('');
      })
      .catch(function () { /* the static message stays in place */ });
  }

  /* ----------------------- the residence apply bar ----------------------- */
  /* It appears once the hero's own Apply button has scrolled away, and gets
     out of the way again over the footer, where the same links already are. */
  var sticky = document.getElementById('res-sticky');
  if (sticky) {
    var hero = document.querySelector('.reshero .hero__actions');
    var foot = document.querySelector('.site-footer');
    sticky.hidden = false;
    document.body.classList.add('has-stickybar');
    var place = function () {
      var past = hero ? hero.getBoundingClientRect().bottom < 0 : window.scrollY > 520;
      var atEnd = foot ? foot.getBoundingClientRect().top < window.innerHeight - 40 : false;
      sticky.classList.toggle('is-up', past && !atEnd);
      document.body.classList.toggle('has-stickybar', past && !atEnd);
    };
    window.addEventListener('scroll', place, { passive: true });
    window.addEventListener('resize', place);
    place();
  }

  /* --------------------------- year in the footer ------------------------ */
  $$('[data-year]').forEach(function (el) { el.textContent = String(new Date().getFullYear()); });
})();
