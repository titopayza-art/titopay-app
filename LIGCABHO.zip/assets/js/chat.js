/**
 * Ligcabho assistant.
 *
 * The front door of the website. It answers the questions students ask,
 * takes an application, logs a maintenance fault with a ticket number, and
 * books a call back — all through the same API the forms use, so everything
 * lands in the admin portal the moment it is said here.
 *
 * It never claims to be a person, and it only sends anyone to WhatsApp when
 * somebody is in danger: that is the emergency line, not the front desk.
 */
(function () {
  'use strict';

  var API = window.LIGCABHO_API_BASE || 'api/';
  var STORE = 'ligcabho.chat';

  var INSTITUTIONS = [
    'University of Mpumalanga (UMP)',
    'Tshwane University of Technology (TUT)',
    'Ehlanzeni TVET College',
    'Eduvos',
    'University of Johannesburg (UJ)',
    'Unigrad College',
    'Other private college'
  ];

  var RESIDENCES = (window.LIGCABHO_RESIDENCES || []).map(function (r) { return r.name; });
  if (!RESIDENCES.length) RESIDENCES = ['No preference — place me'];

  /* Quick answers the assistant can give without leaving the flow. */
  var FAQS = [
    { k: ['nsfas', 'funding', 'fund', 'bursary'],
      a: 'Yes — we take NSFAS funded students, bursary holders and cash paying students at every residence. ' +
         'Send your funding letter once you have applied and we will hold your room.' },
    { k: ['price', 'cost', 'how much', 'rent', 'fee', 'rate'],
      a: 'Rent depends on the residence and whether you take a single or a sharing room. Apply here and the team ' +
         'confirms the exact rate for the house you are placed in, in writing, before you sign anything.' },
    { k: ['available', 'space', 'room left', 'vacancy', 'still have'],
      a: 'Applications for 2027 are open at all seventeen residences. Rooms are allocated as applications come in, ' +
         'so the earlier you apply the more choice you have. Shall I take your application now?' },
    { k: ['wifi', 'internet', 'data'],
      a: 'Every residence has Wi-Fi. Vouchers are issued when your lease is signed, and again at the start of the second term.' },
    { k: ['security', 'safe', 'safety'],
      a: 'Access control and a security service provider at every house, with armed response at 48 Mataffin Hill and ' +
         'selected residences. Emergency numbers are displayed in each building lobby.' },
    { k: ['pool', 'swim'],
      a: 'There are pools at 1 Silver Oak, 23 Dolomiet, 48 Mataffin Hill and 01 Penny Street.' },
    { k: ['transport', 'shuttle', 'bus', 'far', 'distance', 'walk'],
      a: 'Most houses are within walking distance of campus; the rest sit on CityBus or campus shuttle routes.' },
    { k: ['visitor', 'sleepover', 'guest'],
      a: 'Scheduled sleepovers are R135 per person with proof of payment. Unscheduled visitors are R200, charged to ' +
         'your rental account.' },
    { k: ['bank', 'account', 'pay', 'payment', 'deposit', 'proof'],
      a: 'FNB, Ligcabho Properties, business account 62653880552. Use your name and ID number as the reference, and ' +
         'email the proof of payment to admin@ligcabhoresidences.co.za.' },
    { k: ['laundry', 'washing'],
      a: 'Laundry facilities are on site at every residence, and the LVL UP packs include what you need to get going.' },
    { k: ['park', 'car', 'bike'],
      a: 'Off-street parking is available at most residences. Tell the office which house you are placed in and they ' +
         'will confirm a bay.' },
    { k: ['lease', 'contract', 'sign'],
      a: 'The lease is signed online. Once your room is confirmed we email you a private link; you read it, sign it ' +
         'on your phone, and you get a PDF copy the moment it is countersigned.' },
    { k: ['document', 'certificate', 'id copy', 'upload', 'send you'],
      a: 'Documents come to us by email: reply to your confirmation with the file attached, or upload it on the ' +
         'application form. We never ask for documents on social media.' },
    { k: ['maintenance', 'broken', 'fix', 'leak', 'fault', 'repair', 'geyser'],
      a: 'I can log that for you right now and give you a ticket number. Say "report a fault" and I will start.' },
    { k: ['vacate', 'notice', 'moving out', 'cancel'],
      a: 'Notice to vacate is given in writing on the website — one calendar month, and the form walks you through ' +
         'it. Open Notice to vacate from the menu, or ask me for someone to call you.' },
    { k: ['coming back', 'next year', 'return', 'renew', 'retention'],
      a: 'Returning students fill in the retention form and keep first claim on their room. It is in the Student ' +
         'zone menu, and it takes about three minutes.' },
    { k: ['address', 'office', 'where are you', 'visit'],
      a: "Head office is No 11 Liza's Court, 28 Van Rensburg Street, Nelspruit. Open Monday to Friday, office hours." },
    { k: ['human', 'person', 'agent', 'call me', 'phone me', 'talk to someone'],
      a: 'I can have someone call you back — say "call me back" and I will take your number. ' +
         'Or call the office on 013 752 4161 during office hours.' }
  ];

  /* Words that mean "stop the chat and give me numbers". */
  var EMERGENCY_WORDS = ['emergency', 'fire', 'burning', 'smoke', 'flood', 'burst', 'gas leak', 'intruder',
    'break in', 'broke in', 'robbed', 'robbery', 'assault', 'attacked', 'attack', 'stabbed', 'shot',
    'bleeding', 'unconscious', 'ambulance', 'police', 'danger', 'unsafe', 'rape', 'gbv', 'suicide',
    'electric shock', 'hijack'];

  var EMERGENCY_TEXT =
    'If somebody is in danger, stop reading and phone now:\n\n' +
    '  Ligcabho emergency line (24 hours): 071 640 1574 — call, or WhatsApp if you cannot speak\n' +
    '  Police: 10111\n' +
    '  Ambulance and fire: 10177\n' +
    '  From a cellphone: 112\n' +
    '  Gender-based violence command centre: 0800 428 428\n\n' +
    'Then tell your house manager. The full list is on our emergency page.';

  var APPLY_STEPS = [
    { key: 'first_name', ask: 'Great, let us get you a room. What is your first name?',
      check: function (v) { return v.length >= 2 || 'Please type your first name.'; } },

    { key: 'last_name', ask: function (d) { return 'Thanks ' + d.first_name + '. And your surname?'; },
      check: function (v) { return v.length >= 2 || 'Please type your surname.'; } },

    { key: 'id_number', ask: 'What is your South African ID number? (13 digits)',
      check: function (v) {
        var id = v.replace(/\D/g, '');
        if (id.length !== 13) return 'A South African ID number is 13 digits.';
        return validSaId(id) || 'That ID number does not check out — please read it off your ID and try again.';
      },
      clean: function (v) { return v.replace(/\D/g, ''); } },

    { key: 'student_number', ask: 'Your student number? If you do not have one yet, type skip.', skippable: true },

    { key: 'gender', ask: 'Rooms are allocated single gender. Which should I put you down for?',
      options: ['Male', 'Female'] },

    { key: 'phone', ask: 'What is the best number to reach you on?',
      check: function (v) {
        return v.replace(/\D/g, '').length >= 9 || 'That number looks short — please include the dialling code.';
      } },

    { key: 'email', ask: 'And your email address?',
      check: function (v) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v) || 'That email address does not look right.'; } },

    { key: 'level_of_study', ask: 'What level are you studying at?',
      options: ['First year', 'Second year', 'Third year', 'Fourth year', 'Postgraduate', 'Other'] },

    { key: 'institution', ask: 'Where are you studying?', options: INSTITUTIONS, allowFree: true },

    { key: 'funder', ask: 'Who is paying your fees?',
      options: ['NSFAS', 'Bursary', 'Cash paying / self funded', 'Employer / sponsor', 'Other'] },

    { key: 'year_applying', ask: 'Which year are you applying for?', options: ['2027', '2028'] },

    { key: 'residence', ask: 'Which residence would you like? If you are not sure, choose "No preference" and we will ' +
        'place you at a house accredited for your institution.',
      options: ['No preference — place me'].concat(RESIDENCES), allowFree: true },

    { key: 'room_type', ask: 'A single is your own room. Sharing is two students to a room and costs less. Which would you prefer?',
      options: ['Single room', 'Sharing room', 'No preference'] },

    { key: 'notes', ask: 'Anything else we should know — accessibility needs, a move-in date, sharing with a friend? Type skip if not.',
      skippable: true }
  ];



  var FAULT_STEPS = [
    { key: 'residence', ask: 'Which residence are you in?',
      options: RESIDENCES, allowFree: true },

    { key: 'room', ask: 'Which room number?', skippable: true },

    { key: 'category', ask: 'What sort of fault is it?',
      options: ['Plumbing', 'Electrical', 'Appliance', 'Locks and keys', 'Internet', 'Cleaning', 'Something else'] },

    { key: 'urgency', ask: 'How bad is it?',
      options: ['Emergency — someone could get hurt', 'Urgent — I cannot use the room properly', 'Normal'] },

    { key: 'description', ask: 'Tell me what is wrong, in your own words.',
      check: function (v) { return v.length >= 8 || 'A little more detail helps the team bring the right parts.'; } },

    { key: 'name', ask: 'What is your name?',
      check: function (v) { return v.length >= 2 || 'Please type your name.'; } },

    { key: 'phone', ask: 'And a number the team can reach you on?',
      check: function (v) {
        return v.replace(/\D/g, '').length >= 9 || 'That number looks short — please include the dialling code.';
      } },

    { key: 'email', ask: 'Your email, so I can send you the ticket number? Type skip if you would rather not.',
      skippable: true,
      check: function (v) {
        return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v) || 'That email address does not look right — or type skip.';
      } }
  ];

  var CALLBACK_STEPS = [
    { key: 'name', ask: 'Of course. What is your name?',
      check: function (v) { return v.length >= 2 || 'Please type your name.'; } },

    { key: 'phone', ask: 'What number should they call?',
      check: function (v) {
        return v.replace(/\D/g, '').length >= 9 || 'That number looks short — please include the dialling code.';
      } },

    { key: 'email', ask: 'And your email address, so we have it in writing too?',
      check: function (v) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v) || 'That email address does not look right.'; } },

    { key: 'message', ask: 'What is it about? A sentence is enough.',
      check: function (v) { return v.length >= 4 || 'Just a few words about what you need.'; } }
  ];

  var FLOWS = {
    apply: { steps: APPLY_STEPS, endpoint: 'applications',
             intro: 'Perfect. I will ask a few questions, and you can type skip on anything optional.' },
    fault: { steps: FAULT_STEPS, endpoint: 'maintenance',
             intro: 'I will log it and give you a ticket number you can quote.' },
    callback: { steps: CALLBACK_STEPS, endpoint: 'enquiries',
             intro: 'I will put you on the list for a call back during office hours.' }
  };

  /** A South African ID number: 13 digits with the Luhn check digit. */
  function validSaId(v) {
    var id = String(v || '').replace(/\D/g, '');
    if (!/^\d{13}$/.test(id)) return false;
    var sum = 0;
    for (var i = 0; i < 13; i++) {
      var d = Number(id[i]);
      if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
      sum += d;
    }
    return sum % 10 === 0;
  }

  var state = { open: false, flow: null, step: -1, data: {}, key: null, busy: false, greeted: false,
                log: [], queue: [] };

  /* ------------------------------ plumbing ------------------------------ */
  function sessionKey() {
    if (state.key) return state.key;
    try {
      state.key = sessionStorage.getItem(STORE);
    } catch (e) { /* private mode */ }
    if (!state.key) {
      state.key = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      try { sessionStorage.setItem(STORE, state.key); } catch (e) { /* ignore */ }
    }
    return state.key;
  }

  function flush(outcome) {
    if (!state.log.length && !outcome) return;
    var messages = state.log.splice(0, state.log.length);
    fetch(API + 'chat/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ session_key: sessionKey(), messages: messages, outcome: outcome })
    }).catch(function () { /* logging is best effort */ });
  }

  /* --------------------------------- UI --------------------------------- */
  var el = {};

  function build() {
    var wrap = document.createElement('div');
    wrap.className = 'chat';
    wrap.innerHTML =
      '<button class="chat__launch" type="button" aria-expanded="false" aria-controls="chat-panel">' +
        '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" ' +
        'stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-8 8H7l-4 3 1.2-4.2A8 8 0 1 1 21 12z"/>' +
        '</svg><span>Chat to us</span></button>' +
      '<section class="chat__panel" id="chat-panel" hidden aria-label="Ligcabho application assistant">' +
        '<header class="chat__head">' +
          '<div><strong>Ligcabho assistant</strong><span>Applications · faults · questions</span></div>' +
          '<button class="chat__close" type="button" aria-label="Close chat">&times;</button>' +
        '</header>' +
        '<div class="chat__log" id="chat-log" role="log" aria-live="polite"></div>' +
        '<div class="chat__options" id="chat-options"></div>' +
        '<form class="chat__form" id="chat-form">' +
          '<label class="visually-hidden" for="chat-input">Your message</label>' +
          '<input id="chat-input" autocomplete="off" placeholder="Type your answer…">' +
          '<button class="chat__send" type="submit" aria-label="Send">&#8594;</button>' +
        '</form>' +
        '<p class="chat__note">An automated assistant. For a person, call 013 752 4161. In an emergency, 071 640 1574.</p>' +
      '</section>';
    document.body.appendChild(wrap);

    el.root = wrap;
    el.launch = wrap.querySelector('.chat__launch');
    el.panel = wrap.querySelector('.chat__panel');
    el.log = wrap.querySelector('#chat-log');
    el.options = wrap.querySelector('#chat-options');
    el.form = wrap.querySelector('#chat-form');
    el.input = wrap.querySelector('#chat-input');

    el.launch.addEventListener('click', toggle);
    wrap.querySelector('.chat__close').addEventListener('click', toggle);
    el.form.addEventListener('submit', function (e) {
      e.preventDefault();
      var v = el.input.value.trim();
      if (!v) return;
      el.input.value = '';
      handle(v);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && state.open) toggle();
    });
  }

  function toggle() {
    state.open = !state.open;
    el.panel.hidden = !state.open;
    el.launch.setAttribute('aria-expanded', String(state.open));
    el.root.classList.toggle('is-open', state.open);
    if (state.open) {
      if (!state.greeted) greet();
      setTimeout(function () { el.input.focus(); }, 80);
    } else {
      flush(state.flow ? 'abandoned' : 'open');
    }
  }

  function bubble(role, text) {
    var p = document.createElement('div');
    p.className = 'chat__msg chat__msg--' + role;
    p.textContent = text;
    el.log.appendChild(p);
    el.log.scrollTop = el.log.scrollHeight;
    state.log.push({ role: role === 'bot' ? 'bot' : 'user', text: text });
  }

  function say(text, delay) {
    state.busy = true;
    var typing = document.createElement('div');
    typing.className = 'chat__msg chat__msg--bot chat__typing';
    typing.innerHTML = '<span></span><span></span><span></span>';
    el.log.appendChild(typing);
    el.log.scrollTop = el.log.scrollHeight;
    setTimeout(function () {
      typing.remove();
      bubble('bot', text);
      state.busy = false;
      if (state.queue.length) {
        var next = state.queue.shift();
        setTimeout(function () { handle(next); }, 60);
      }
    }, delay || Math.min(900, 260 + text.length * 8));
  }

  function options(list) {
    el.options.innerHTML = '';
    (list || []).forEach(function (o) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'chat__chip';
      b.textContent = o;
      b.addEventListener('click', function () { handle(o); });
      el.options.appendChild(b);
    });
  }

  /* ------------------------------- the flow ------------------------------ */

  var MENU = ['Apply for a room', 'Report a fault', 'Ask a question', 'Ask someone to call me'];

  function steps() {
    return state.flow ? FLOWS[state.flow].steps : [];
  }

  function greet() {
    state.greeted = true;
    say('Hi! I am the Ligcabho assistant. I can take your application for 2027, log a maintenance fault, answer ' +
        'questions about our residences, or get someone to call you back.', 500);
    setTimeout(function () {
      say('What do you need?');
      options(MENU);
    }, 700);
  }

  function faqAnswer(text) {
    var t = text.toLowerCase();
    for (var i = 0; i < FAQS.length; i++) {
      for (var j = 0; j < FAQS[i].k.length; j++) {
        if (t.indexOf(FAQS[i].k[j]) !== -1) return FAQS[i].a;
      }
    }
    return null;
  }

  function isEmergency(text) {
    var t = ' ' + text.toLowerCase() + ' ';
    for (var i = 0; i < EMERGENCY_WORDS.length; i++) {
      if (t.indexOf(EMERGENCY_WORDS[i]) !== -1) return true;
    }
    return false;
  }

  /** Everything stops for an emergency, wherever we are in the chat. */
  function emergency() {
    say(EMERGENCY_TEXT, 300);
    flush('emergency');
    setTimeout(function () {
      options(['Call 071 640 1574', 'WhatsApp the emergency line', 'Report a fault', 'I am safe, carry on']);
    }, 900);
  }

  function handle(text) {
    // Students type faster than the assistant answers: hold the answer rather
    // than losing it, and deal with it as soon as the reply lands.
    if (state.busy) {
      state.queue.push(text);
      return;
    }
    bubble('user', text);
    options([]);

    /* The emergency line is the one thing that interrupts anything. */
    if (/^call 071/i.test(text)) { window.location.href = 'tel:+27716401574'; return; }
    if (/^whatsapp the emergency/i.test(text)) {
      window.open('https://wa.me/27716401574?text=' + encodeURIComponent('Ligcabho emergency: '), '_blank', 'noopener');
      say('Opening WhatsApp. If nobody answers within a minute, phone 071 640 1574, then 10111.');
      return;
    }
    if (/^i am safe/i.test(text)) {
      state.flow = null;
      state.step = -1;
      say('Good. What can I help you with?');
      setTimeout(function () { options(MENU); }, 700);
      return;
    }
    /* Only outside a flow: mid-answer, "the bathroom is flooding" is the
       description of a fault, not a cry for help, and eating it would lose
       what the student just typed. The fault flow asks how bad it is, and
       says to phone if the answer is bad. */
    if (!state.flow && isEmergency(text)) return emergency();

    /* Nothing started yet: the menu, or a question. */
    if (!state.flow) {
      if (/^apply|room for 2027|book a room/i.test(text)) return start('apply');
      if (/^report a fault|maintenance|log a fault/i.test(text)) return start('fault');
      if (/call me|call back|ring me|phone me|talk to a person|speak to someone/i.test(text)) return start('callback');

      var a = faqAnswer(text);
      say(a || 'I can help with rooms and rates, funding, applications, maintenance, leases, payments and moving ' +
              'out — or get someone to call you. What would you like?');
      setTimeout(function () { options(MENU); }, 900);
      return;
    }

    /* Inside a flow: check the answer, then move on. */
    var list = steps();
    if (state.step < list.length) {
      var step = list[state.step];
      var value = text.trim();

      if (/^(skip|none|no)$/i.test(value) && step.skippable) {
        state.data[step.key] = '';
        return next();
      }
      if (step.clean) value = step.clean(value);
      if (step.check) {
        var verdict = step.check(value);
        if (verdict !== true) {
          say(verdict);
          setTimeout(function () { ask(state.step); }, 800);
          return;
        }
      }
      state.data[step.key] = value;
      return next();
    }
  }

  function start(flow) {
    state.flow = flow;
    state.step = 0;
    state.data = {};
    say(FLOWS[flow].intro, 500);
    setTimeout(function () { ask(0); }, 800);
  }

  function ask(i) {
    var step = steps()[i];
    var q = typeof step.ask === 'function' ? step.ask(state.data) : step.ask;
    say(q);
    setTimeout(function () {
      options(step.options || (step.skippable ? ['Skip'] : []));
      el.input.placeholder = step.options && !step.allowFree ? 'Choose above, or type your answer…' : 'Type your answer…';
    }, 500);
  }

  function next() {
    state.step++;
    if (state.step < steps().length) {
      setTimeout(function () { ask(state.step); }, 350);
      return;
    }
    submit();
  }

  /** Back to the menu once something has been sent. */
  function done(outcome) {
    state.flow = null;
    state.step = -1;
    state.data = {};
    flush(outcome);
  }

  function post(endpoint, payload) {
    return fetch(API + endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(payload)
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok || j.ok === false) throw new Error(j.error || 'Something went wrong. Please try again.');
        return j;
      });
    });
  }

  function submit() {
    var flow = state.flow;
    var d = state.data;

    if (flow === 'apply') return submitApplication(d);
    if (flow === 'fault') return submitFault(d);
    return submitCallback(d);
  }

  function submitApplication(d) {
    say('Thank you. Sending your application now…', 400);
    post('applications', {
      first_name: d.first_name, last_name: d.last_name, id_number: d.id_number,
      student_number: d.student_number || '', gender: d.gender || '',
      phone: d.phone, email: d.email, level_of_study: d.level_of_study || '',
      institution: d.institution || '', funder: d.funder || '', year_applying: d.year_applying || '',
      residence: /no preference/i.test(d.residence || '') ? '' : (d.residence || ''),
      room_type: d.room_type || '', notes: d.notes || '', source: 'chat', consent: 'yes'
    }).then(function (res) {
      say('Done! Your reference is ' + res.ref + '. A confirmation is on its way to ' + d.email + '.', 500);
      setTimeout(function () {
        say('Still to send a proof of payment or a funding letter? Reply to that email with the file attached and ' +
            'we will finish your placement. Anything else I can do?');
        options(['Report a fault', 'Ask a question', 'Nothing, thanks']);
      }, 1000);
      done('applied');
    }).catch(function (err) {
      say('I could not send that: ' + err.message);
      setTimeout(function () {
        say('You can also apply on the application form, or I can ask someone to call you.');
        options(['Try again', 'Ask someone to call me']);
        state.step = steps().length - 1;
      }, 900);
    });
  }

  function submitFault(d) {
    say('Logging it now…', 400);
    var urgency = /emergency/i.test(d.urgency || '') ? 'emergency'
                : (/urgent/i.test(d.urgency || '') ? 'urgent' : 'standard');
    post('maintenance', {
      residence: d.residence, room: d.room || '', name: d.name, phone: d.phone,
      email: d.email || '', category: d.category || '', urgency: urgency,
      description: d.description, source: 'chat'
    }).then(function (res) {
      say('Logged. Your ticket number is ' + res.ref + ' — quote it if you phone the office.', 500);
      setTimeout(function () {
        if (urgency !== 'emergency' && isEmergency(d.description || '')) {
          say('That sounds as though it cannot wait until morning. Phone the 24 hour line on 071 640 1574 as well, ' +
              'and quote ' + res.ref + '.');
          options(['Call 071 640 1574', 'Nothing, thanks']);
        } else if (urgency === 'emergency') {
          say('Because you marked it an emergency, phone the 24 hour line as well on 071 640 1574 so somebody ' +
              'comes out tonight. Do not wait for email.');
          options(['Call 071 640 1574', 'WhatsApp the emergency line', 'Nothing, thanks']);
        } else {
          say('The house manager sees it straight away, and you will hear from us once it is assigned. ' +
              'Anything else?');
          options(['Apply for a room', 'Ask a question', 'Nothing, thanks']);
        }
      }, 1000);
      done('maintenance');
    }).catch(function (err) {
      say('I could not log that: ' + err.message);
      setTimeout(function () {
        say('Please use the Report maintenance form on the website, or phone 013 752 4161.');
        options(['Try again']);
        state.step = steps().length - 1;
      }, 900);
    });
  }

  function submitCallback(d) {
    say('Sending that through…', 400);
    post('enquiries', {
      kind: 'callback', name: d.name, phone: d.phone, email: d.email,
      topic: 'Call back requested', message: d.message, source: 'chat'
    }).then(function () {
      say('Done. The office has your number and will call you during office hours, Monday to Friday.', 500);
      setTimeout(function () {
        say('If it cannot wait, phone 013 752 4161 now. Anything else I can help with?');
        options(['Apply for a room', 'Report a fault', 'Nothing, thanks']);
      }, 1000);
      done('callback');
    }).catch(function (err) {
      say('I could not send that: ' + err.message);
      setTimeout(function () {
        say('Please phone 013 752 4161 and the office will help you straight away.');
        options(['Try again']);
        state.step = steps().length - 1;
      }, 900);
    });
  }

  /* -------------------------------- start -------------------------------- */
  if (!document.body.hasAttribute('data-no-chat')) {
    build();
    window.addEventListener('beforeunload', function () {
      if (state.log.length) flush(state.flow ? 'abandoned' : 'open');
    });
    // Any "apply by chat" link on the page opens the assistant.
    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-open-chat]');
      if (!t) return;
      e.preventDefault();
      if (!state.open) toggle();
      /* data-open-chat="fault" opens straight into that flow. */
      var want = t.getAttribute('data-open-chat');
      if (want && FLOWS[want]) {
        setTimeout(function () { if (!state.flow) start(want); }, 900);
      }
    });
  }
})();
