This folder holds the SQLite database and the files students upload
(proofs of payment, funding letters, CVs).

It must stay writable by the web server, and it must never be served:
the .htaccess files here deny all web access. Back this folder up — it is
the only copy of your applications, leases, reviews and notices.
