# Ligcabho Le'Africa Residences — website, digital leases and admin portal

A complete rebuild of ligcabhoresidences.co.za: 40 pages, a staff portal, an application assistant, a
digital lease agreement with server-generated PDFs, a JSON API and an admin portal. No build step
and no framework —
upload the folder and it runs on ordinary PHP hosting.

---

## 1. What is in the box

```
START-HERE.txt            read this before uploading
version.txt               the build stamp, to prove an upload landed
index.php                 front door: takes over from WordPress, keeps old links working
deploy-check.php          open it after uploading; delete it once the site is up
set-password.php          emergency password reset; it deletes itself after use

/                         19 content pages + 17 residence pages
  index.html              home
  residences.html         all residences, filterable by institution, area and room type
  residence-*.html        one page per residence, with photo gallery and enquiry form
  apply.html              online application (document upload, or apply by chat)
  student-zone.html       lease, house rules, emergency list, what to do in week one
  report-maintenance.html report a fault and get a ticket number
  refund-request.html     claim a refund, overpayment or deposit back
  student-retention.html  the returning-student form: are you coming back next year?
  reviews.html            published student reviews + leave a review
  notice-to-vacate.html   give notice / cancel a lease
  lvl-up.html             LVL UP kitchen (R700) and bedding (R600) packs + order forms
  student-safety.html     safety features and emergency procedure
  emergency.html          emergency contact list
  about-us.html           who we are, vision, how the residence is run
  accreditations.html     UMP, TUT, NSFAS, bursary, cash
  urban-regeneration.html
  careers.html            job search + application form with CV upload
  faqs.html               the full FAQ, marked up as schema.org FAQPage
  house-rules.html        the eleven house rule policies
  get-in-touch.html       contact details, banking details, contact form
  lease.html              the digital lease a tenant opens, reads and signs
  404.html, sitemap.xml, robots.txt, .htaccess

/assets
  css/styles.css          the design system
  css/chat.css            the application assistant
  css/lease.css           the lease agreement (screen and print)
  js/main.js              nav, filters, lightbox, forms, published reviews
  js/chat.js              the application assistant
  js/lease.js             lease rendering and signature capture
  js/residences.js        residence list, generated at build time
  img/…                   brand marks, residence photographs, institution logos
  docs/…                  lease agreement, house rules, emergency numbers (PDF)

/api
  config.php              everything an installation changes lives here
  bootstrap.php           database, schema, sessions, mail, uploads, helpers
  index.php               the API routes
  pdf.php                 a small PDF writer, no dependencies
  docs.php                builds the signed lease and house rules as PDFs
  .htaccess               routes /api/... to index.php

/data                     created on first run, never served
  ligcabho.sqlite         the database
  uploads/                proofs of payment, funding letters, CVs

/staff                    the staff portal (noindex)
  index.html              what the team can send in, and the rules they work by
  requests.html           leave, notice, claims and grievances
  supplies.html           cleaning and consumable requisitions

/admin
  index.html, admin.css, admin.js
  vendor/                 XLSX and jsPDF, for Excel and PDF exports
```

## 2. Deploying (Afrihost, cPanel or any PHP host)

**Read `START-HERE.txt` first** — it covers the two things that make an upload look like it did
nothing: the wrong folder on an addon domain, and WordPress still booting.

1. In cPanel's File Manager, open `public_html/`, upload `LIGCABHO.zip` and **Extract** it there.
   The archive holds the files at its top level, so `index.html` lands directly in `public_html/`
   with nothing to move afterwards. Delete the zip once it has extracted.
2. **Select PHP Version**: PHP 8.1 or newer, with `pdo_sqlite`, `sqlite3`, `openssl` and `fileinfo`
   ticked. (The code also runs on 7.4 — the two PHP 8 string helpers it uses are polyfilled.)
3. Make `data/` writable by the web server (755 is usually enough, 775 if not).
4. Open `https://ligcabhoresidences.co.za/deploy-check.php`. It reports what actually arrived,
   whether the domain serves this folder, whether WordPress is still in the way, and whether email
   can go out. Fix anything in red, then delete that file.
5. Open `https://ligcabhoresidences.co.za/` to check the site, then `/admin/` to sign in.
6. Set email up under **Messages → Setup** and send yourself a test. Section 5 has the settings.

`index.php` deliberately overwrites WordPress's own `index.php` — without it, cPanel keeps booting
WordPress and the old site keeps showing. Old WordPress addresses (`/about-us/`, `/student-zone/`,
`/8-jan-frederik/` and the rest) redirect to the matching new page. Once the new site is confirmed,
delete the WordPress files; `deploy-check.php` lists which are still there.

The database, the tables, the five staff accounts, the seventeen residences and the current
vacancy are all created automatically on the first request. There is nothing to import.

**Prefer MySQL** (or your package has no SQLite)? Create the database and user in cPanel's *MySQL
Databases*, add the user to the database with all privileges, then set `driver => 'mysql'` and the
credentials in `api/config.php`. Afrihost prefixes both the database and the user with your account
name — copy them exactly as cPanel shows them. The schema is created on the next request.

## 3. Admin portal

`https://ligcabhoresidences.co.za/admin/`

| Email                               | Role    | Can do                                                  |
|-------------------------------------|---------|---------------------------------------------------------|
| admin@ligcabhoresidences.co.za      | Owner   | Everything, including staff accounts and the activity log |
| ceo@ligcabhoresidences.co.za        | Owner   | Everything, including staff accounts                     |
| e.director@ligcabhoresidences.co.za | Owner   | Everything, including staff accounts                     |
| manager@ligcabhoresidences.co.za    | Manager | All records, leases, vacancies, rates, deletions          |
| support@ligcabhoresidences.co.za    | Staff   | Read records, change status, add notes                    |

**Temporary password for all five: `#47LigcabhoRes`** — every account must set its own password
(10 characters or more, and not the temporary one) at first sign-in.

### Today
One inbox of everything waiting on the office: new applications, enquiries, maintenance tickets,
notices to vacate, reviews to publish, leases to counter-sign, job applications and pack orders.
Each row opens the record itself. Four tiles underneath show what is outstanding.

### The views

- **Applications** — search, filter by status, open the full record, view the uploaded proof of
  payment, move the status along (new → reviewing → accepted / waitlist / placed / rejected),
  keep internal notes, email or WhatsApp the applicant, and **create their lease in one click**.
- **Leases** — create a lease (it fills itself in from the rate card), send it to the tenant by
  email, watch it come back signed, counter-sign it, or cancel it. Every lease has its own
  unguessable link. The agreement is Ligcabho Le'Africa Properties' own lease, clause for clause:
  twelve numbered clauses from Definitions to Special conditions, with the blanks (the property,
  the dates, the rent, the admin fee, the deposit, the occupancy limit in 5.4) filled in from the
  record. The signing page reads those clauses from the same code that writes the PDF, so what a
  student agrees to on screen and what the signed document says cannot drift apart.
- **Retention** — the returning students. Who is coming back, who is leaving and why, what room they
  want, whether their funding is confirmed, and how they rated the year. Open one and **create their
  new lease in one click** — it carries their room and residence across.
- **Finance** — outstanding, overdue, invoices and refunds to pay across the top. Build an invoice or
  a quote from as many lines as you need, send it (the student gets it by email with the banking
  details and the reference on it), download it as a PDF, and mark it paid. Overdue invoices are
  flagged red and land in Today.
- **Messages** — write to a student from the portal. Twelve ready letters to start from
  (documents outstanding, accepted, waiting list, declined, room confirmed, payment reminder,
  maintenance update, notice acknowledged, refund approved, returning students, newsletter), each
  filling in their name, reference, residence, room and amount by itself. Every record view also has
  a **Send email** button that opens the same window already addressed. **Message a group** sends
  the same letter to newsletter subscribers, applicants at a given status, students coming back, or
  tenants on a signed lease — one email each, so nobody sees anybody else's address. Every message
  is kept with who sent it and whether the server accepted it, and **Test email** proves delivery
  works on the host.
- **Enquiries**, **Maintenance**, **Cancellations**, **Reviews**, **LVL UP orders**, **Careers**,
  **Newsletter** — the same pattern: search, filter, open, set status, note, export.
- **Reviews** — publish, reply publicly, or hide. Published reviews appear on `reviews.html`
  straight away, with the office reply underneath.
- **Residences & rates** — capacity, how many beds are placed, how many are free, and the **rate
  card**: single rate, sharing rate, deposit and administration fee per residence. New leases read
  their money fields from here, and can still be overridden per lease.
- **Refunds** — overpayments, double payments, cancellations and deposit refunds, with the
  claimant's proof of payment and banking details on the record.
- **Staff requests** — leave, notice, claims and grievances sent in from the staff portal, with
  any attached certificate or slip.
- **Supplies** — cleaning and consumable requisitions per residence, marked urgent where they are.
- **Chat transcripts** — every conversation the assistant had, and how it ended (applied, fault
  logged, call back booked, emergency, abandoned).
- **Dashboard** — occupancy per residence, who is funding students, where applications stand.
- **Staff accounts** and **Activity log** — owners only.

Exports: Excel, PDF and CSV from every record view.

## 4. What students can do on the site

### The assistant comes first

The chat button is on every page, and it is the way the site expects students to reach us. It can:

- **take a whole application** — the same questions as the form, the same application record, about
  two minutes on a phone;
- **log a maintenance fault** and read back the ticket number (MNT…) then and there;
- **book a call back** — name, number and what it is about, which lands in Enquiries;
- **answer the questions students actually ask** — rates, NSFAS and funding, availability, Wi-Fi,
  security, visitors, banking details, leases, documents, parking, laundry, moving out and coming
  back next year;
- **recognise an emergency**. If somebody types fire, flood, intruder, assault or the like, it stops
  whatever it was doing and puts the emergency numbers on the screen.

It never claims to be a person, and every conversation is kept under **Chatbot** in the portal.

**WhatsApp is for emergencies only.** It is not on any page as a way to enquire, apply or send
documents; it appears once, on the emergency page, beside the 24-hour number, for someone who cannot
speak. Everything else goes through the assistant, the forms, email, or the office line. Documents
come back by email — students are told to reply to their confirmation with the file attached.

### Everything else

- Apply online with documents, **or apply by chat** — the assistant asks the same questions and
  creates the same application (it never pretends to be a person).
- Log a maintenance request and get a ticket number (MNT…) that the house warden works from.
- Give notice to vacate and get a reference (CXL…), with the notice period and inspection
  explained up front.
- Leave a review of their residence, which the office publishes or answers.
- Claim a refund (REF…) with a proof of payment and banking details attached.
- Say whether they are coming back next year on the **student retention form** (RET…) — seven
  sections covering their current room, next year's funding, the room they want, a roommate request
  and an honest review of the year.
- Download the signed lease and the house rules as PDFs, generated on the server.
- Order LVL UP packs, subscribe to the newsletter, apply for a job, enquire about any residence.

Everything above lands in the portal the moment it is submitted, and is emailed to the office.

## 5. Email

Email is the way the site talks to students, so it is set up from the portal rather than from a
file: **Messages → Setup**, as any owner or manager.

### The two ways out

| | What it is | When to use it |
|---|---|---|
| **SMTP** | The site signs in to a real mailbox and sends through it | Always, if you can. It works on hosts that block everything else, and the mail is far less likely to be filed as spam |
| **The host's mail server** | PHP hands the message to cPanel | Fine if a test email actually arrives. Many hosts refuse it |

Leave the setting on *Automatically* and it uses SMTP as soon as a server is filled in.

**The domain's own mailbox** (make it in cPanel under *Email Accounts* first):

```
Server    mail.ligcabhoresidences.co.za
Port      587        Security  TLS
Username  admin@ligcabhoresidences.co.za      (the full address)
Password  the mailbox password
```

**Gmail or Google Workspace:**

```
Server    smtp.gmail.com
Port      587        Security  TLS
Username  the Gmail address
Password  an APP PASSWORD — not the account password
```

Google will not accept the ordinary password. Make an app password at
myaccount.google.com → Security → 2-Step Verification → App passwords.

If the test says the encrypted connection could not be set up, the host's certificate is for its own
name rather than yours: set **Certificate** to *Do not check it* and test again.

### What goes out by itself

| When | To the office | To the person |
|---|---|---|
| An application is submitted | the full application | their reference and what happens next |
| An enquiry, cancellation notice, refund claim, review, retention form, pack order, job application, staff request or supply request comes in | the submission | a receipt with the reference |
| A maintenance fault is logged | the fault | their ticket number, in writing |
| A lease is sent | — | the signing link, **with the lease attached as a PDF** |
| A lease is signed | the signed lease | their copy, **with the lease and house rules attached** |
| An invoice or quote is sent | — | the amount, banking details and reference, **with the PDF attached** |

Every one of them is a proper email: plain text and a laid-out HTML version, so it reads well on a
phone. Anything you write yourself goes out from **Messages → Letters**.

### Every email, under the person it was sent to

Open any record — an application, a lease, a maintenance ticket, a refund claim — and its **Emails**
list shows everything that address has ever been sent: the letters the office wrote and the ones the
website sent by itself, in date order, each one opening to show what it actually said. A failure shows
its reason there too, so "has anyone told them?" is answered on the record rather than by searching a
log.

### Proving it works, and what happens when it does not

Press **Test email** (on any Messages tab) and send one to yourself. That is the only proof.

**Messages → Delivery** lists every email the site has ever tried to send — what went, what did not,
and the mail server's own words for why. A failed one can be sent again from the same screen, one at
a time or all at once, and an attached lease or invoice is rebuilt when it goes.

Nothing is ever lost when email fails: the application, the ticket or the claim behind it is already
saved in the portal. Email is how people are told, not how anything is kept.

Common answers the log gives:

- *The sender address was refused* — `from` must be a real mailbox on this domain.
- *The password was refused* — on Gmail, that means an app password is needed.
- *Could not reach the server on port 587* — the host blocks the port; try 465 with SSL, or ask them.

## 6. Security notes

- Passwords are hashed with `password_hash()` (bcrypt). The temporary password cannot be reused
  as a new password.
- Sign-in is rate limited to 8 attempts per IP per 15 minutes.
- Sessions are HTTP-only, SameSite=Lax and Secure over HTTPS, and expire after 8 hours.
- ID numbers are validated (13 digits with the Luhn check digit) in the browser and again on the
  server.
- Uploads live in `data/uploads`, are never served by Apache, and are only readable through
  `/api/files/<name>` by a signed-in staff member.
- Lease links use a 32-character random token; a lease cannot be opened before it is sent, cannot
  be signed twice, and only accepts a signature when the typed name matches the lease exactly.
- Every sign-in, failed sign-in, record change, lease action and account change is written to the
  activity log.
- Applicant records contain ID numbers: treat the portal as POPIA-sensitive and do not share
  logins.

## 7. The year's cycle

The portal follows a student from first enquiry to the next year:

```
apply (or chat)  ->  application  ->  lease sent  ->  signed  ->  in residence
                                                                      |
                              maintenance, reviews, refunds, invoices  |
                                                                      v
                          retention form  ->  coming back  ->  new lease for next year
                                          ->  leaving      ->  notice to vacate, deposit refund
```

Retention forms open before applications for the next year, so returning students are placed first.
Everything in that cycle lands in **Today**.

## 8. PDFs

The lease and the house rules are typeset on the server, with no library to install:

- `/api/lease/<token>/pdf` — the tenant's own signed lease, from the link they were emailed.
- `/api/leases/<id>/pdf` — the same document from the portal, for staff.
- `/api/docs/house-rules.pdf` — the house rules, for anyone.

The clause text lives in `api/docs.php` and mirrors `assets/js/lease.js`, so the PDF reads exactly
as the lease the tenant signed on screen. Change one, change the other.

## 9. Changing things

- **Rates** — Residences & rates in the portal. Nothing to edit in code.
- **Email recipients, bank details, landlord details, session length** — `api/config.php`.
- **The announcement** ("Applications for 2027 now open") — search the HTML files for that text.
- **Photographs** — `assets/img/residences/`, named after their residence.
- **Lease clauses** — `assets/js/lease.js` (on screen) and `api/docs.php` (the PDF).
- **If a password is lost** — upload `set-password.php`, open it, set a new one; it self-deletes.

## 10. Local preview

```
php -S localhost:8000        # from the site root — serves the pages and the API
```

Then open http://localhost:8000/ and http://localhost:8000/admin/.
