<?php
/**
 * Deployment check.
 *
 * Open https://ligcabhoresidences.co.za/deploy-check.php after uploading. It reports
 * what is actually in the folder on the server, so a failed upload or a
 * leftover WordPress install is visible instead of being guessed at.
 *
 * Delete this file once the site is up. It shows no passwords or data.
 */
declare(strict_types=1);

/* PHP 7.4 is still the default on some accounts. These two arrived in PHP 8;
   defining them costs nothing and keeps this file working either way. */
if (!function_exists('str_contains')) {
    function str_contains(string $h, string $n): bool { return $n === '' || strpos($h, $n) !== false; }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $h, string $n): bool { return strncmp($h, $n, strlen($n)) === 0; }
}

$root = __DIR__;

$build = is_file("$root/version.txt")
    ? trim((string)(explode("\n", (string)file_get_contents("$root/version.txt"))[1] ?? ''))
    : 'version.txt is missing';

$ours = ['index.html', 'index.php', '.htaccess', 'residences.html', 'student-zone.html',
         'apply.html', 'lease.html', 'report-maintenance.html', 'refund-request.html',
         'notice-to-vacate.html', 'reviews.html',
         'staff/index.html', 'staff/requests.html', 'staff/supplies.html',
         'assets/css/styles.css', 'assets/js/main.js', 'assets/js/chat.js', 'assets/js/lease.js',
         'admin/index.html', 'admin/admin.js', 'admin/.htaccess',
         'api/index.php', 'api/config.php', 'api/bootstrap.php', 'api/docs.php', 'api/pdf.php',
         'data/.htaccess'];

$wordpress = ['wp-config.php', 'wp-load.php', 'wp-settings.php', 'wp-blog-header.php',
              'wp-admin', 'wp-includes', 'wp-content', 'xmlrpc.php'];

$leftovers = array_values(array_filter($wordpress, fn($f) => file_exists("$root/$f")));
$missing   = array_values(array_filter($ours, fn($f) => !file_exists("$root/$f")));

$indexPhpIsOurs = is_file("$root/index.php")
    && str_contains((string)file_get_contents("$root/index.php"), 'take over from WordPress');

/* Clean URLs need mod_rewrite and an .htaccess the host is allowed to read.
   Both are normal on cPanel, but a host that ignores .htaccess would leave
   every /about-us style address 404-ing, so it is worth saying out loud. */
$htaccess   = is_file("$root/.htaccess") ? (string)file_get_contents("$root/.htaccess") : '';
$hasClean   = str_contains($htaccess, 'Clean URLs');
$hasRewrite = function_exists('apache_get_modules')
    ? in_array('mod_rewrite', (array)apache_get_modules(), true) : null;

/* The question that matters when an upload "does nothing": is the folder these
   files are sitting in the same folder the domain is served from? On an addon
   domain in cPanel it often is not, and uploading to public_html changes
   nothing visible. */
$here    = rtrim(str_replace('\\', '/', $root), '/');
$docroot = rtrim(str_replace('\\', '/', (string)($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
$sameDir = $docroot !== '' && realpath($here) === realpath($docroot);

$host = preg_replace('/^www\./', '', (string) ($_SERVER['HTTP_HOST'] ?? 'ligcabhoresidences.co.za'));
/* Can this host send email at all, and who does it send as? */
$disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
$canMail  = function_exists('mail') && !in_array('mail', $disabled, true);
$mailOn   = true;
$mailFrom = 'admin@ligcabhoresidences.co.za';
if (is_readable("$root/api/config.php")) {
    $conf = @include "$root/api/config.php";
    if (is_array($conf) && isset($conf['mail'])) {
        $mailOn   = !empty($conf['mail']['enabled']);
        $mailFrom = (string) ($conf['mail']['from'] ?? $mailFrom);
    }
}

function row(string $label, string $value, string $state): string {
    $colour = ['good' => '#0f8a52', 'bad' => '#c0392b', 'warn' => '#b4690e'][$state];
    return '<tr><th style="text-align:left;padding:.5rem .9rem;border-bottom:1px solid #e7e0d7;font-weight:600">'
        . htmlspecialchars($label) . '</th><td style="padding:.5rem .9rem;border-bottom:1px solid #e7e0d7;color:'
        . $colour . ';font-weight:600">' . htmlspecialchars($value) . '</td></tr>';
}

header('Content-Type: text/html; charset=utf-8');
?><!doctype html>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ligcabho deployment check</title>
<style>
 body{margin:0;background:#f7f4ef;color:#221c18;
   font:15px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
 .wrap{max-width:760px;margin:0 auto;padding:32px 18px 60px}
 h1{font-size:1.5rem;margin:0 0 .3rem} p{color:#4a403a}
 table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;
   overflow:hidden;box-shadow:0 1px 3px rgba(34,28,24,.1);margin:18px 0}
 .box{background:#fff;border-radius:12px;padding:16px 18px;margin:18px 0;
   box-shadow:0 1px 3px rgba(34,28,24,.1);border-left:4px solid #f5951d}
 .box--bad{border-left-color:#c0392b} .box--good{border-left-color:#0f8a52}
 code{background:#f7f4ef;padding:.1rem .35rem;border-radius:4px;font-size:.88em}
 ol{padding-left:1.2rem} li{margin:.4rem 0}
</style>
<div class="wrap">
<h1>Ligcabho deployment check</h1>
<p>What is actually on the server right now.</p>

<table>
<?= row('Build on the server', $build, str_contains($build, 'missing') ? 'bad' : 'good') ?>
<?= row('Front door (index.php)', $indexPhpIsOurs ? 'Ours, WordPress is not booting'
        : (file_exists("$root/index.php") ? 'NOT ours, WordPress may still be serving' : 'Not uploaded'),
        $indexPhpIsOurs ? 'good' : 'bad') ?>
<?= row('Apache config (.htaccess)', file_exists("$root/.htaccess") ? 'Uploaded' : 'MISSING, hidden files were skipped',
        file_exists("$root/.htaccess") ? 'good' : 'bad') ?>
<?= row('Database folder protected', file_exists("$root/data/.htaccess") ? 'Yes' : 'MISSING',
        file_exists("$root/data/.htaccess") ? 'good' : 'bad') ?>
<?= row('Our files missing', $missing ? implode(', ', $missing) : 'None, all present',
        $missing ? 'bad' : 'good') ?>
<?= row('WordPress left behind', $leftovers ? implode(', ', $leftovers) : 'None, cleaned out',
        $leftovers ? 'warn' : 'good') ?>
<?= row('This folder', $here ?: 'unknown', 'good') ?>
<?= row('Folder the domain serves', $docroot ?: 'not reported by the server', $docroot === '' ? 'warn' : ($sameDir ? 'good' : 'bad')) ?>
<?= row('Uploaded to the right place', $docroot === '' ? 'Cannot tell, check the two paths above'
        : ($sameDir ? 'Yes' : 'NO, these are different folders'), $sameDir ? 'good' : 'bad') ?>
<?= row('Clean URL rules', $hasClean ? 'In .htaccess' : 'MISSING, an old .htaccess is still up there',
        $hasClean ? 'good' : 'bad') ?>
<?= row('mod_rewrite', $hasRewrite === null ? 'Cannot tell from PHP, test the link below'
        : ($hasRewrite ? 'Enabled' : 'NOT enabled, ask the host to switch it on'),
        $hasRewrite === false ? 'bad' : ($hasRewrite ? 'good' : 'warn')) ?>
<?= row('PHP version', PHP_VERSION, version_compare(PHP_VERSION, '8.0', '>=') ? 'good' : 'bad') ?>
<?= row('SQLite available', extension_loaded('pdo_sqlite') ? 'Yes' : 'NO, the admin portal will not run',
        extension_loaded('pdo_sqlite') ? 'good' : 'bad') ?>
<?= row('Database writable', is_writable("$root/data") ? 'Yes' : 'NO, set data/ to 755',
        is_writable("$root/data") ? 'good' : 'bad') ?>
<?= row('Email (PHP mail)', $canMail ? 'Available' : 'BLOCKED by the host, no email will go out',
        $canMail ? 'good' : 'bad') ?>
<?= row('Emails are sent from', $mailFrom . ($mailOn ? '' : '  (sending is switched off in api/config.php)'),
        $mailOn ? 'good' : 'warn') ?>
</table>

<div class="box">
  <strong>Prove that email works before you tell students to apply.</strong>
  <p>Sign in at <a href="/admin/">/admin/</a>, open <strong>Messages</strong> and press
  <strong>Test email</strong>. Send it to your own address. If it arrives, everything the
  website sends &mdash; application confirmations, leases, invoices, the letters you write
  from the portal &mdash; will reach people.</p>
  <p>If it does not arrive, open <strong>Messages &rarr; Setup</strong> and send through a real
  mailbox instead (SMTP). For this domain that is <code>mail.<?= htmlspecialchars($host) ?></code>
  on port 587 with TLS, signing in as a mailbox you created in cPanel under <em>Email Accounts</em>.
  It works on hosts that block PHP mail altogether, and the mail is far less likely to be treated
  as spam.</p>
  <p>The address the site sends <em>from</em>, <code><?= htmlspecialchars($mailFrom) ?></code>, must
  be a real mailbox on this domain either way. Hosts refuse to send from an address they do not own,
  and Gmail drops it too.</p>
</div>

<div class="box">
  <strong>Check the clean URLs by hand, it takes ten seconds.</strong>
  <p>Open <a href="/about-us">/about-us</a>. It must show the About Us page, not a 404.
  Then open <a href="/about-us.html">/about-us.html</a>: it must bounce you back to
  <code>/about-us</code> in the address bar.</p>
  <p>If the first one 404s, the host is ignoring <code>.htaccess</code> or
  <code>mod_rewrite</code> is off. The site still works either way, because
  <code>index.php</code> resolves the same addresses in PHP, but ask the host to enable
  rewriting so pages are served without PHP.</p>
</div>

<?php if ($docroot !== '' && !$sameDir): ?>
<div class="box box--bad">
  <strong>The files are in the wrong folder. This is why nothing changed.</strong>
  <p>These files are in:<br><code><?= htmlspecialchars($here) ?></code></p>
  <p>But <?= htmlspecialchars((string)($_SERVER['HTTP_HOST'] ?? 'this domain')) ?> is served from:<br>
     <code><?= htmlspecialchars($docroot) ?></code></p>
  <p>Move the contents into the second folder. In cPanel this usually happens when
  the domain is an <strong>addon domain</strong>, so its home is not
  <code>public_html</code> but a folder inside it.</p>
</div>
<?php endif; ?>

<?php if ($leftovers): ?>
<div class="box box--bad">
  <strong>WordPress is still installed in this folder.</strong>
  <p>The new site will serve correctly now that <code>index.php</code> is ours, but the old
  files are dead weight and a security risk, because an unpatched WordPress is the most
  common way a site gets hacked.</p>
  <p>In cPanel &rarr; File Manager, delete these from <code>public_html</code>:</p>
  <ol><?php foreach ($leftovers as $f): ?><li><code><?= htmlspecialchars($f) ?></code></li><?php endforeach; ?></ol>
  <p>Do not delete anything else. Everything the new site needs is listed above as present.</p>
</div>
<?php endif; ?>

<?php if ($missing): ?>
<div class="box box--bad">
  <strong>Part of the upload did not arrive.</strong>
  <p>Missing: <code><?= htmlspecialchars(implode(', ', $missing)) ?></code></p>
  <p>If the missing names start with a dot, your FTP client or File Manager is hiding
  them. Turn on "show hidden files" and upload again.</p>
</div>
<?php elseif (!$leftovers): ?>
<div class="box box--good">
  <strong>Everything is in place.</strong>
  <p>Delete this file (<code>deploy-check.php</code>) now that the site is up.</p>
</div>
<?php endif; ?>

<div class="box">
  <strong>Still seeing the old site?</strong>
  <ol>
    <li>Hard refresh: <code>Ctrl+Shift+R</code>, or <code>Cmd+Shift+R</code> on a Mac.</li>
    <li>Try it in a private window, which ignores your browser cache entirely.</li>
    <li>If your host runs LiteSpeed or Cloudflare, clear that cache in cPanel.</li>
    <li>Check the build date at the top of this page matches the one you were given.</li>
  </ol>
</div>
</div>
